/// Level 1 OrderBook types (top of books).
pub mod l1;
