# План интеграции компонентов FreqTrade в NautilusTrader

**Дата создания**: 2025-01-XX  
**Источник**: `/home/crypto/sites/cryptotrader.com/freqtrade/COMPLETE_ANALYTICS_GUIDE.md`

---

## 📊 Анализ компонентов FreqTrade

### ✅ Что уже есть в NautilusTrader

1. **PostgreSQL загрузка данных** - есть (`jesse_postgresql_loader.py`)
2. **Kaiko API интеграция** - частично (в тестах)
3. **База данных результатов** - есть (`backtest_results_db.py`)
4. **Система рейтинга** - базовая (в веб-интерфейсе)
5. **Веб-интерфейс** - есть (Streamlit)
6. **Метрики** - расширенные (expectancy, max_consecutive, fees)

### 🎯 Что нужно добавить из FreqTrade

#### Приоритет 1: Критически важно

1. **Multi-Exchange Data Parser**
   - Загрузка данных с Binance, Gate.io, KuCoin
   - Автоматический fallback между биржами
   - Не требует API ключей для публичных данных
   - **Файл**: `multi_exchange_data_parser.py`
   - **Путь в FreqTrade**: `/home/crypto/sites/cryptotrader.com/freqtrade/multi_exchange_data_parser.py`

2. **Advanced Profitability Calculator**
   - Расчет реальной доходности с учетом:
     - Кешбека по рефералке (Binance 30%, Bybit 40%, Gate.io 50%/60%)
     - Проскальзываний (зависит от депозита)
     - Спредов
     - Комиссий (spot/futures)
     - Плеча
   - **Файл**: `advanced_profitability_calculator.py`
   - **Путь в FreqTrade**: `/home/crypto/sites/cryptotrader.com/freqtrade/advanced_profitability_calculator.py`

#### Приоритет 2: Важно для удобства

3. **DateTime Helpers**
   - Утилиты для работы с датами и временем
   - Всегда работают с UTC
   - Единообразная обработка миллисекунд
   - **Файл**: `datetime_helpers.py`
   - **Путь в FreqTrade**: `/home/crypto/sites/cryptotrader.com/freqtrade/freqtrade/util/datetime_helpers.py`

4. **Exchange Utils**
   - Конвертация таймфреймов (`timeframe_to_minutes`, `timeframe_to_seconds`)
   - Округление цен (`price_to_precision`)
   - Валидация бирж
   - **Файл**: `exchange_utils.py`
   - **Путь в FreqTrade**: `/home/crypto/sites/cryptotrader.com/freqtrade/freqtrade/exchange/exchange_utils.py`

5. **Strategy Helpers**
   - `merge_informative_pair()` - объединение данных без lookahead bias
   - `stoploss_from_open()` - расчет стоп-лосса от цены входа
   - `stoploss_from_absolute()` - расчет стоп-лосса от абсолютной цены
   - **Файл**: `strategy_helper.py`
   - **Путь в FreqTrade**: `/home/crypto/sites/cryptotrader.com/freqtrade/freqtrade/strategy/strategy_helper.py`

#### Приоритет 3: Улучшения

6. **Улучшенная система рейтинга (Ninja Score)**
   - Взвешенная оценка стратегии
   - Формула с весами для разных метрик
   - Детекция lookahead bias
   - **Файл**: `strategy_rating_system_standalone.py`
   - **Путь в FreqTrade**: `/home/crypto/sites/cryptotrader.com/freqtrade/strategy_rating_system_standalone.py`

7. **Strategy Optimizer (Optuna)**
   - Гиперпараметрическая оптимизация
   - Multi-objective оптимизация
   - Визуализация результатов
   - **Файл**: `strategy_optimizer_optuna.py`
   - **Путь в FreqTrade**: `/home/crypto/sites/cryptotrader.com/freqtrade/strategy_optimizer_optuna.py`

---

## 🚀 План интеграции

### Этап 1: Multi-Exchange Data Parser (1-2 часа)

**Цель**: Добавить возможность загрузки данных с нескольких бирж

**Шаги**:

1. Создать `nautilus_trader/persistence/multi_exchange_loader.py`
2. Адаптировать код из FreqTrade под NautilusTrader
3. Интегрировать в веб-интерфейс как новый источник данных
4. Добавить в `.cursorrules`

**Преимущества**:

- Автоматический fallback между биржами
- Не требует API ключей для публичных данных
- Поддержка множества таймфреймов

### Этап 2: Advanced Profitability Calculator (2-3 часа)

**Цель**: Добавить расчет реальной доходности с учетом всех издержек

**Шаги**:

1. Создать `nautilus_trader/analysis/profitability_calculator.py`
2. Адаптировать код из FreqTrade
3. Интегрировать в веб-интерфейс (новая вкладка или секция)
4. Добавить расчет кешбека, проскальзываний, спредов

**Преимущества**:

- Реальная доходность с учетом всех издержек
- Сравнение бирж
- Расчет оптимальной стратегии

### Этап 3: DateTime Helpers (30 минут)

**Цель**: Добавить утилиты для работы с датами

**Шаги**:

1. Создать `nautilus_trader/common/datetime_helpers.py`
2. Скопировать и адаптировать функции из FreqTrade
3. Использовать в существующем коде

**Преимущества**:

- Единообразная обработка времени
- Избежание проблем с часовыми поясами

### Этап 4: Exchange Utils (1 час)

**Цель**: Добавить утилиты для работы с биржами

**Шаги**:

1. Создать `nautilus_trader/common/exchange_utils.py`
2. Адаптировать функции конвертации таймфреймов
3. Добавить округление цен

**Преимущества**:

- Удобная конвертация таймфреймов
- Правильное округление цен

### Этап 5: Strategy Helpers (1-2 часа)

**Цель**: Добавить хелперы для стратегий

**Шаги**:

1. Создать `nautilus_trader/trading/strategy_helpers.py`
2. Адаптировать `merge_informative_pair`, `stoploss_from_open`
3. Использовать в примерах стратегий

**Преимущества**:

- Избежание lookahead bias
- Удобные функции для стоп-лоссов

### Этап 6: Улучшенная система рейтинга (2-3 часа)

**Цель**: Улучшить систему рейтинга с Ninja Score

**Шаги**:

1. Изучить формулу Ninja Score из FreqTrade
2. Адаптировать под метрики NautilusTrader
3. Обновить веб-интерфейс с новым рейтингом
4. Добавить детекцию lookahead bias

**Преимущества**:

- Более точный рейтинг стратегий
- Детекция проблемных стратегий

### Этап 7: Strategy Optimizer (опционально, 3-4 часа)

**Цель**: Добавить оптимизацию стратегий через Optuna

**Шаги**:

1. Установить Optuna
2. Создать `nautilus_trader/optimization/optuna_optimizer.py`
3. Интегрировать в веб-интерфейс
4. Добавить визуализацию результатов

**Преимущества**:

- Автоматическая оптимизация параметров
- Multi-objective оптимизация

---

## 📋 Чеклист интеграции

### Критически важно (сделать в первую очередь)

- [ ] Multi-Exchange Data Parser
- [ ] Advanced Profitability Calculator
- [ ] DateTime Helpers
- [ ] Exchange Utils

### Важно (сделать после критических)

- [ ] Strategy Helpers
- [ ] Улучшенная система рейтинга (Ninja Score)

### Опционально (можно отложить)

- [ ] Strategy Optimizer (Optuna)

---

## 🔧 Технические детали

### Адаптация кода

При адаптации кода из FreqTrade нужно:

1. **Изменить импорты**:

   ```python
   # Было (FreqTrade):
   from freqtrade.util import dt_now
   
   # Стало (NautilusTrader):
   from nautilus_trader.common.datetime_helpers import dt_now
   ```

2. **Использовать абсолютные пути**:

   ```python
   # Всегда использовать Path(__file__).parent.resolve()
   NAUTILUS_DIR = Path(__file__).parent.resolve()
   DATA_DIR = NAUTILUS_DIR / "data"
   ```

3. **Следовать стилю NautilusTrader**:
   - Type hints обязательны
   - NumPy-style docstrings
   - PEP 8 стиль

4. **Интегрировать с существующими компонентами**:
   - Использовать существующие модели данных
   - Интегрировать с веб-интерфейсом
   - Сохранять в PostgreSQL

---

## 📊 Формула Ninja Score (из FreqTrade)

```python
NINJA_WEIGHTS = {
    "buys": 9,
    "avgprof": 26,
    "totprofp": 26,
    "winp": 24,
    "ddp": -25,              # Отрицательный вес
    "stoploss": 7,
    "sharpe": 7,
    "sortino": 7,
    "calmar": 7,
    "expectancy": 8,
    "profit_factor": 9,
    "cagr": 10,
    "rejected_signals": -25,  # Отрицательный вес
    "backtest_win_percentage": 10
}
```

**Адаптация для NautilusTrader**:

- `buys` → `total_trades`
- `avgprof` → `avg_win`
- `totprofp` → `total_return_pct`
- `winp` → `win_rate`
- `ddp` → `max_drawdown_pct`
- `sharpe` → `sharpe_ratio`
- `expectancy` → `expectancy`
- `profit_factor` → `profit_factor`

---

## 🎯 Рекомендации

1. **Начать с Multi-Exchange Data Parser** - это даст максимальную пользу сразу
2. **Добавить Advanced Profitability Calculator** - покажет реальную доходность
3. **Улучшить систему рейтинга** - сделает сравнение стратегий более точным
4. **Оптимизатор оставить на потом** - требует больше времени и зависимостей

---

## 📝 Примечания

- Все компоненты из FreqTrade требуют адаптации под архитектуру NautilusTrader
- Некоторые компоненты могут иметь зависимости, которые нужно установить
- Код из FreqTrade может использовать другие библиотеки (например, pandas вместо встроенных типов NautilusTrader)
- Нужно протестировать все интегрированные компоненты

---

**Последнее обновление**: 2025-01-XX  
**Статус**: План создан, ожидает реализации

