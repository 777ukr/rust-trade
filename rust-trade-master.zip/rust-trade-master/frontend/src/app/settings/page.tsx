export default function Settings() {
    return <div>Settings Page</div>;
  }