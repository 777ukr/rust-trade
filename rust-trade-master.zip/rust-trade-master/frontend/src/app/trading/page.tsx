export default function Trading() {
    return <div>Trading Page</div>;
  }