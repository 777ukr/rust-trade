#!/usr/bin/env python3
"""
Полный набор бэктестов для всех стратегий с правильным сохранением результатов
для отображения в веб-интерфейсе Freqtrade
"""

import json
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional
import time

FREQTRADE_DIR = Path(__file__).parent
CONFIG_PATH = FREQTRADE_DIR.parent / "config" / "freqtrade_config.json"
STRATEGIES_DIR = FREQTRADE_DIR / "user_data" / "strategies"
RESULTS_DIR = FREQTRADE_DIR / "user_data" / "backtest_results"

# Параметры
END_DATE = datetime.now().strftime("%Y%m%d")
START_DATE = (datetime.now() - timedelta(days=30)).strftime("%Y%m%d")
TIMERANGE = f"{START_DATE}-{END_DATE}"
TIMEFRAME = "5m"
PAIR = "BTC/USDT"


def find_strategies() -> List[str]:
    """Находит все стратегии"""
    strategies = []
    for file in STRATEGIES_DIR.glob("*.py"):
        if file.name != "__init__.py" and not file.name.startswith("_"):
            strategy_name = file.stem
            if strategy_name != "TestStrategy":  # Пропускаем базовую тестовую стратегию
                strategies.append(strategy_name)
    return strategies


def run_backtest_properly(strategy_name: str) -> Optional[Dict]:
    """
    Запускает бэктест с правильными параметрами для сохранения в веб-интерфейс
    Freqtrade автоматически создает JSON файлы когда используется --export trades
    """
    print(f"\n{'='*70}")
    print(f"🧪 Тестирование: {strategy_name} на {PAIR}")
    print(f"{'='*70}")
    
    cmd = [
        "freqtrade", "backtesting",
        "--config", str(CONFIG_PATH),
        "--strategy", strategy_name,
        "--timerange", TIMERANGE,
        "--timeframe", TIMEFRAME,
        "--pairs", PAIR,
        "--export", "trades",  # Это важно для создания JSON файлов
        "--breakdown", "month",
        "--cache", "none"
    ]
    
    print(f"📋 Команда: {' '.join(cmd)}")
    
    try:
        start_time = time.time()
        result = subprocess.run(
            cmd,
            cwd=str(FREQTRADE_DIR),
            capture_output=True,
            text=True,
            timeout=600
        )
        
        elapsed = time.time() - start_time
        
        if result.returncode != 0:
            print(f"❌ Ошибка (код {result.returncode})")
            if result.stderr:
                print(f"   {result.stderr[:500]}")
            return None
        
        # Ищем созданные файлы
        # Freqtrade создает файлы в формате: backtest-result-YYYYMMDD_HHMMSS.zip и .meta.json
        time.sleep(1)  # Даем время на создание файлов
        
        # Ищем последние созданные файлы
        meta_files = sorted(
            RESULTS_DIR.glob("*.meta.json"),
            key=lambda x: x.stat().st_mtime,
            reverse=True
        )
        
        if meta_files:
            latest_meta = meta_files[0]
            print(f"✅ Результаты сохранены: {latest_meta.name}")
            print(f"⏱️  Время выполнения: {elapsed:.1f} сек")
            
            # Парсим метаданные
            try:
                meta_data = json.loads(latest_meta.read_text())
                strategy_key = list(meta_data.keys())[0] if meta_data else None
                
                return {
                    "strategy": strategy_name,
                    "meta_file": latest_meta.name,
                    "zip_file": latest_meta.name.replace(".meta.json", ".zip"),
                    "timestamp": latest_meta.stat().st_mtime,
                    "pair": PAIR,
                    "timerange": TIMERANGE,
                    "timeframe": TIMEFRAME,
                    "elapsed_seconds": elapsed,
                    "success": True
                }
            except Exception as e:
                print(f"⚠️  Не удалось прочитать метаданные: {e}")
                return {
                    "strategy": strategy_name,
                    "meta_file": latest_meta.name,
                    "success": True
                }
        else:
            print(f"⚠️  Метафайл не найден, но бэктест выполнен")
            # Проверяем вывод на наличие сделок
            if "Total trades" in result.stdout or "Total/Daily Avg Trades" in result.stdout:
                print(f"✅ Бэктест выполнен успешно (сделки найдены в выводе)")
                return {
                    "strategy": strategy_name,
                    "success": True,
                    "note": "Метафайл не создан, но бэктест выполнен"
                }
            return None
            
    except subprocess.TimeoutExpired:
        print(f"⏱️  Таймаут при тестировании {strategy_name}")
        return None
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        return None


def check_web_ui_accessibility():
    """Проверяет доступность веб-интерфейса"""
    import requests
    
    try:
        response = requests.get("http://127.0.0.1:8081/api/v1/ping", timeout=2)
        if response.status_code == 200:
            return True
    except:
        pass
    return False


def create_summary_report(results: List[Dict]):
    """Создает итоговый отчет"""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    
    summary = {
        "generated_at": datetime.now().isoformat(),
        "total_strategies_tested": len(results),
        "successful_tests": len([r for r in results if r.get("success")]),
        "failed_tests": len([r for r in results if not r.get("success")]),
        "results": results,
        "web_ui_url": "http://127.0.0.1:8081/backtesting",
        "api_history_url": "http://127.0.0.1:8081/api/v1/backtest/history"
    }
    
    summary_file = RESULTS_DIR / "backtest_summary.json"
    with open(summary_file, 'w') as f:
        json.dump(summary, f, indent=2)
    
    print(f"\n📊 Итоговый отчет: {summary_file}")
    return summary_file


def main():
    """Главная функция"""
    print("🚀 Полный набор бэктестов для веб-интерфейса Freqtrade")
    print(f"📅 Период: {TIMERANGE} ({TIMEFRAME})")
    print(f"💰 Пара: {PAIR}")
    print(f"📁 Результаты: {RESULTS_DIR}")
    print(f"{'='*70}\n")
    
    # Проверяем доступность веб-интерфейса
    if not check_web_ui_accessibility():
        print("⚠️  Веб-интерфейс недоступен на http://127.0.0.1:8081")
        print("💡 Убедитесь, что freqtrade запущен с веб-сервером")
        print("   Команда: freqtrade trade --config ../config/freqtrade_config.json\n")
    
    # Находим стратегии
    strategies = find_strategies()
    print(f"🔍 Найдено стратегий: {len(strategies)}")
    for s in strategies:
        print(f"   - {s}")
    print()
    
    if not strategies:
        print("❌ Стратегии не найдены!")
        return
    
    # Тестируем каждую стратегию
    results = []
    for i, strategy in enumerate(strategies, 1):
        print(f"\n[{i}/{len(strategies)}]")
        result = run_backtest_properly(strategy)
        if result:
            results.append(result)
        time.sleep(1)  # Небольшая задержка между тестами
    
    # Создаем итоговый отчет
    if results:
        summary_file = create_summary_report(results)
        
        print(f"\n{'='*70}")
        print("✅ Тестирование завершено!")
        print(f"{'='*70}")
        print(f"\n📊 Успешно протестировано: {len(results)} стратегий")
        print(f"\n🌐 Откройте результаты в веб-интерфейсе:")
        print(f"   http://127.0.0.1:8081/backtesting")
        print(f"\n📁 Итоговый отчет: {summary_file}")
        print(f"\n💡 Если результаты не видны в веб-интерфейсе:")
        print(f"   1. Обновите страницу (F5)")
        print(f"   2. Проверьте раздел 'Backtest History'")
        print(f"   3. Используйте API: http://127.0.0.1:8081/api/v1/backtest/history")
    else:
        print("\n❌ Нет результатов для отображения")
        print("💡 Проверьте ошибки выше")


if __name__ == "__main__":
    main()

