#!/usr/bin/env python3
"""
Extended Statistics Module
Расширенная статистика и сравнение стратегий по монетам
"""

import os
import json
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime
import psycopg2
from psycopg2.extras import RealDictCursor

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://postgres:postgres@localhost:5432/cryptotrader"
)


class ExtendedStatistics:
    """Расширенная статистика стратегий"""
    
    def __init__(self, database_url: str = DATABASE_URL):
        self.database_url = database_url
    
    def get_connection(self):
        """Получить соединение с БД"""
        return psycopg2.connect(self.database_url)
    
    def get_strategy_performance_by_pair(self, strategy_name: str) -> Dict:
        """Получить производительность стратегии по парам"""
        conn = self.get_connection()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                # Получаем результаты бэктестов по парам
                cur.execute("""
                    SELECT 
                        pair,
                        COUNT(*) as backtest_count,
                        AVG(total_profit_pct) as avg_profit,
                        AVG(win_rate) as avg_win_rate,
                        AVG(total_trades) as avg_trades,
                        AVG(profit_factor) as avg_profit_factor,
                        AVG(sharpe_ratio) as avg_sharpe
                    FROM backtest_results
                    WHERE strategy_name = %s
                    GROUP BY pair
                    ORDER BY avg_profit DESC
                """, (strategy_name,))
                
                results = cur.fetchall()
                return {
                    "strategy": strategy_name,
                    "by_pair": [dict(r) for r in results],
                    "total_pairs": len(results)
                }
        finally:
            conn.close()
    
    def compare_strategies_by_pair(self, pair: str, strategies: List[str]) -> Dict:
        """Сравнить стратегии по конкретной паре"""
        conn = self.get_connection()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                placeholders = ','.join(['%s'] * len(strategies))
                cur.execute(f"""
                    SELECT 
                        strategy_name,
                        AVG(total_profit_pct) as avg_profit,
                        AVG(win_rate) as avg_win_rate,
                        AVG(total_trades) as avg_trades,
                        AVG(profit_factor) as avg_profit_factor,
                        AVG(sharpe_ratio) as avg_sharpe,
                        COUNT(*) as backtest_count
                    FROM backtest_results
                    WHERE pair = %s AND strategy_name IN ({placeholders})
                    GROUP BY strategy_name
                    ORDER BY avg_profit DESC
                """, [pair] + strategies)
                
                results = cur.fetchall()
                return {
                    "pair": pair,
                    "strategies": [dict(r) for r in results]
                }
        finally:
            conn.close()
    
    def get_top_strategies_by_pair(self, pair: str, limit: int = 10) -> List[Dict]:
        """Получить топ-стратегии для конкретной пары"""
        conn = self.get_connection()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    SELECT 
                        strategy_name,
                        AVG(total_profit_pct) as avg_profit,
                        AVG(win_rate) as avg_win_rate,
                        AVG(total_trades) as avg_trades,
                        AVG(profit_factor) as avg_profit_factor,
                        AVG(sharpe_ratio) as avg_sharpe,
                        COUNT(*) as backtest_count
                    FROM backtest_results
                    WHERE pair = %s
                    GROUP BY strategy_name
                    HAVING COUNT(*) >= 3
                    ORDER BY avg_profit DESC
                    LIMIT %s
                """, (pair, limit))
                
                results = cur.fetchall()
                return [dict(r) for r in results]
        finally:
            conn.close()
    
    def get_best_pairs_for_strategy(self, strategy_name: str, limit: int = 10) -> List[Dict]:
        """Получить лучшие пары для стратегии"""
        conn = self.get_connection()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    SELECT 
                        pair,
                        AVG(total_profit_pct) as avg_profit,
                        AVG(win_rate) as avg_win_rate,
                        AVG(total_trades) as avg_trades,
                        AVG(profit_factor) as avg_profit_factor,
                        COUNT(*) as backtest_count
                    FROM backtest_results
                    WHERE strategy_name = %s
                    GROUP BY pair
                    HAVING COUNT(*) >= 3 AND AVG(total_profit_pct) > 0
                    ORDER BY avg_profit DESC
                    LIMIT %s
                """, (strategy_name, limit))
                
                results = cur.fetchall()
                return [dict(r) for r in results]
        finally:
            conn.close()
    
    def get_pair_statistics(self, pair: str) -> Dict:
        """Получить общую статистику по паре"""
        conn = self.get_connection()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    SELECT 
                        COUNT(DISTINCT strategy_name) as strategy_count,
                        COUNT(*) as total_backtests,
                        AVG(total_profit_pct) as avg_profit_all,
                        MAX(total_profit_pct) as best_profit,
                        MIN(total_profit_pct) as worst_profit,
                        AVG(win_rate) as avg_win_rate,
                        AVG(total_trades) as avg_trades
                    FROM backtest_results
                    WHERE pair = %s
                """, (pair,))
                
                result = cur.fetchone()
                return dict(result) if result else {}
        finally:
            conn.close()
    
    def generate_comparison_report(self, pair: str, strategies: List[str]) -> str:
        """Сгенерировать отчет сравнения"""
        comparison = self.compare_strategies_by_pair(pair, strategies)
        
        report = f"\n{'='*70}\n"
        report += f"📊 Сравнение стратегий для {pair}\n"
        report += f"{'='*70}\n\n"
        
        for i, strategy in enumerate(comparison["strategies"], 1):
            report += f"{i}. {strategy['strategy_name']}\n"
            report += f"   Profit: {strategy['avg_profit']:.2f}% | "
            report += f"Win Rate: {strategy['avg_win_rate']:.2f}% | "
            report += f"Trades: {strategy['avg_trades']:.1f} | "
            report += f"Sharpe: {strategy['avg_sharpe']:.2f}\n"
            report += f"   Backtests: {strategy['backtest_count']}\n\n"
        
        return report


def main():
    """Пример использования"""
    stats = ExtendedStatistics()
    
    # Примеры
    pair = "BTC/USDT"
    
    print(f"\n📊 Статистика для {pair}:")
    pair_stats = stats.get_pair_statistics(pair)
    print(json.dumps(pair_stats, indent=2))
    
    print(f"\n🏆 Топ-стратегии для {pair}:")
    top_strategies = stats.get_top_strategies_by_pair(pair, limit=5)
    for strategy in top_strategies:
        print(f"  {strategy['strategy_name']}: {strategy['avg_profit']:.2f}%")


if __name__ == "__main__":
    main()

