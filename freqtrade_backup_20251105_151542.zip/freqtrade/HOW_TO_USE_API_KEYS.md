# 🔑 Как использовать API ключи Gate.io

## ✅ Простой способ - ключи уже в конфиге!

Ваши ключи Gate.io **уже есть** в конфиге Freqtrade:
- Файл: `/home/crypto/sites/cryptotrader.com/config/freqtrade_config.json`
- Секция: `exchange.key` и `exchange.secret`

**Парсеры теперь автоматически используют ключи из конфига!** 🎉

## 📋 Три способа установки ключей

### Способ 1: Использовать ключи из конфига (✅ Автоматически)

Парсеры теперь **автоматически** читают ключи из конфига Freqtrade.

Просто запускайте парсеры - они сами найдут ключи:
```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
python3 gateio_coin_parser.py
python3 gateio_data_parser.py
```

Если видите `✅ API ключи Gate.io найдены (из конфига)` - всё работает!

### Способ 2: Переменные окружения

Если хотите использовать другие ключи (не из конфига):

```bash
# Временно (только для текущей сессии)
export GATEIO_API_KEY="your_api_key_here"
export GATEIO_SECRET_KEY="your_secret_key_here"

# Затем запускайте парсеры
python3 gateio_coin_parser.py
```

**Или постоянно (добавить в ~/.bashrc):**
```bash
# Откройте файл
nano ~/.bashrc

# Добавьте в конец:
export GATEIO_API_KEY="your_api_key_here"
export GATEIO_SECRET_KEY="your_secret_key_here"

# Сохраните (Ctrl+O, Enter, Ctrl+X)
# Перезагрузите
source ~/.bashrc
```

### Способ 3: Прямо в конфиге Freqtrade

Ключи уже там! Откройте файл:
```bash
nano /home/crypto/sites/cryptotrader.com/config/freqtrade_config.json
```

Найдите секцию:
```json
"exchange": {
  "name": "gateio",
  "key": "ваш_ключ_здесь",
  "secret": "ваш_секрет_здесь",
  ...
}
```

## 🎯 Проверка работы

Запустите парсер:
```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
python3 gateio_coin_parser.py
```

**Если видите:**
- `✅ API ключи Gate.io найдены (из конфига)` - всё ОК!
- `⚠️  API ключи Gate.io не найдены` - ключи не найдены, но парсер работает без них

## 💡 Где взять ключи?

1. Зайдите на https://www.gate.io/
2. Войдите в аккаунт
3. Account → API Management
4. Create API Key
5. **Важно:** Выберите только **Read** права (для чтения данных)
6. Скопируйте API Key и Secret Key

## 📝 Пример

**Текущая настройка:**
- Ключи в конфиге: `/home/crypto/sites/cryptotrader.com/config/freqtrade_config.json`
- Парсеры автоматически их используют ✅

**Ничего делать не нужно!** Просто запускайте парсеры.

## ❓ FAQ

**Q: Ключи нужны обязательно?**
A: Нет! Парсеры работают без ключей для публичных данных.

**Q: Зачем тогда ключи?**
A: Для увеличения лимитов запросов (быстрее скачивание).

**Q: Ключи в конфиге безопасны?**
A: Да, конфиг не должен быть в публичном доступе. Используйте `.gitignore`.

