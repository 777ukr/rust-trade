# 🚀 Полная система рейтинга стратегий

## 🎯 Цели системы

1. ✅ **Веб-интерфейс** для управления стратегиями
2. ✅ **PostgreSQL** для хранения всех данных
3. ✅ **Фильтры и сортировки** по всем параметрам
4. ✅ **Запуск бэктестов** прямо из интерфейса
5. ✅ **Парсинг истории** с Gate.io
6. ✅ **Расчет доходности** с учетом комиссий
7. ✅ **Управление стратегиями** (удаление, деактивация)

## 📋 Компоненты системы

### 1. FastAPI Backend (`rating_api_server.py`)
- REST API для всех операций
- Интеграция с PostgreSQL
- Фоновые задачи для бэктестов
- Статистика и аналитика

### 2. PostgreSQL Database
- `strategy_ratings` - рейтинги стратегий
- `strategy_backtest_metrics` - метрики бэктестов
- `backtest_results` - результаты бэктестов
- `strategy_ranking_history` - история рейтингов

### 3. Веб-интерфейс (планируется)
- React/Vue.js фронтенд
- Фильтры и сортировки
- Управление стратегиями
- Запуск бэктестов
- Визуализация результатов

## 🚀 Установка

### 1. Установить зависимости:

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate
pip install -r requirements_rating.txt
```

### 2. Настроить PostgreSQL:

```bash
# Применить схему
export DATABASE_URL="postgresql://postgres:postgres@localhost:5432/cryptotrader"
psql "$DATABASE_URL" -f ../database/strategy_rating_schema.sql
```

### 3. Запустить API сервер:

```bash
python3 rating_api_server.py
```

Сервер запустится на `http://localhost:8889`

## 📊 API Endpoints

### Получить рейтинг стратегий:
```
GET /api/rankings?min_trades=10&min_profit=0&sort_by=ninja_score&order=desc
```

### Запустить бэктест:
```
POST /api/backtest/run
{
  "strategy_name": "MShotStrategy",
  "pairs": ["BTC/USDT", "ETH/USDT"],
  "timeframe": "5m",
  "leverage": 1
}
```

### Получить список стратегий:
```
GET /api/strategies
```

### Удалить стратегию:
```
DELETE /api/strategies/{strategy_name}
```

### Получить статистику:
```
GET /api/stats
```

## 🔧 Текущий статус

- ✅ Добавлены стратегии: E0V1E_20231004_085308, ElliotV5_SMA
- ✅ Создан FastAPI сервер
- ✅ Интеграция с PostgreSQL
- 🚧 Веб-интерфейс (планируется)
- 🚧 Парсер истории Gate.io (планируется)
- 🚧 Расчет комиссий (планируется)

## 📝 Следующие шаги

1. Создать полноценный веб-интерфейс
2. Добавить парсер истории с Gate.io
3. Реализовать расчет доходности с комиссиями
4. Добавить автоматическое обновление рейтингов
5. Создать систему уведомлений



