#!/bin/bash
# Комплексный запуск всех тестов системы рейтинга

cd "$(dirname "$0")"

echo "🧪 ЗАПУСК ВСЕХ ТЕСТОВ СИСТЕМЫ РЕЙТИНГА"
echo "========================================"
echo ""

# Проверка что сервер запущен
if ! curl -s http://localhost:8889/ > /dev/null 2>&1; then
    echo "⚠️  Сервер не запущен. Запускаю..."
    nohup python3 rating_api_server.py > api_server.log 2>&1 &
    sleep 3
    echo "✅ Сервер запущен"
fi

echo ""
echo "1️⃣  Тестирование API endpoints..."
python3 test_api_endpoints.py

echo ""
echo "2️⃣  Комплексное тестирование системы..."
python3 test_complete_system.py

echo ""
echo "3️⃣  E2E тестирование веб-интерфейса..."
python3 test_web_ui_e2e.py

echo ""
echo "✅ Все тесты завершены!"
echo ""
echo "📊 Откройте интерфейс: http://localhost:8889"

