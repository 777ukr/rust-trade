# 🔑 Настройка API ключей Gate.io

## ⚠️ Важно

**Для публичных данных (список пар, свечи) API ключи НЕ обязательны!**

Парсеры работают без ключей, используя публичные эндпоинты Gate.io API.

## 📋 Когда нужны API ключи

API ключи нужны только для:
- ✅ Увеличения rate limits (больше запросов в секунду)
- ✅ Доступа к приватным данным (баланс, ордера)
- ✅ Торговых операций

## 🔧 Настройка (опционально)

### 1. Получить API ключи

1. Зайдите на https://www.gate.io/
2. Account → API Management
3. Создайте новый API ключ
4. **Важно:** Выберите только права на **Read** (чтение данных)
5. Скопируйте API Key и Secret Key

### 2. Установить переменные окружения

```bash
export GATEIO_API_KEY="your_api_key_here"
export GATEIO_SECRET_KEY="your_secret_key_here"
```

Или добавить в `~/.bashrc`:
```bash
echo 'export GATEIO_API_KEY="your_api_key_here"' >> ~/.bashrc
echo 'export GATEIO_SECRET_KEY="your_secret_key_here"' >> ~/.bashrc
source ~/.bashrc
```

### 3. Проверить настройку

```bash
echo $GATEIO_API_KEY
echo $GATEIO_SECRET_KEY
```

## 📊 Использование без ключей

Парсеры работают **без ключей** для:
- ✅ Получения списка торговых пар
- ✅ Скачивания исторических свечей
- ✅ Получения статистики по парам

## ⚡ Rate Limits

**Без API ключей:**
- ~10 запросов в секунду
- Достаточно для скачивания данных

**С API ключами:**
- До 100 запросов в секунду (зависит от уровня аккаунта)
- Быстрее скачивание больших объемов данных

## 🔍 Проверка работы

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade

# Парсер монет (работает без ключей)
python3 gateio_coin_parser.py

# Парсер данных (работает без ключей)
python3 gateio_data_parser.py
```

Если видите:
- `✅ API ключи Gate.io найдены` - ключи настроены
- `⚠️  API ключи Gate.io не настроены` - работаем без ключей (нормально)

## ❌ Ошибки

Если получаете ошибки 429 (Too Many Requests):
1. Установите API ключи (увеличат лимиты)
2. Или добавьте задержки между запросами

## 📝 Пример

```bash
# Без ключей (работает)
cd /home/crypto/sites/cryptotrader.com/freqtrade
python3 gateio_coin_parser.py

# С ключами (работает быстрее)
export GATEIO_API_KEY="your_key"
export GATEIO_SECRET_KEY="your_secret"
python3 gateio_coin_parser.py
```

