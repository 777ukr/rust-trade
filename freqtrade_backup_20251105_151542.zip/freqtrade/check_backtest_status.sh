#!/bin/bash
# Проверка статуса бэктестов

cd "$(dirname "$0")"

echo "🔍 Проверка статуса бэктестов..."
echo ""

# 1. Активные процессы
echo "1. Активные процессы Freqtrade:"
ps aux | grep "[f]reqtrade.*backtest" || echo "   Нет активных бэктестов"
echo ""

# 2. Последние результаты
echo "2. Последние 5 результатов:"
ls -lth user_data/backtest_results/*.zip 2>/dev/null | head -5 || echo "   Нет результатов"
echo ""

# 3. Новые файлы (последние 5 минут)
echo "3. Новые результаты (последние 5 минут):"
find user_data/backtest_results -name "*.zip" -mmin -5 2>/dev/null | wc -l | xargs -I {} echo "   Найдено: {} файлов"
echo ""

# 4. Последние логи API
echo "4. Последние записи в логе API:"
tail -20 api_server.log | grep -E "backtest|Бэктест|Запуск|завершен" | tail -5 || echo "   Нет записей"
echo ""

# 5. Логи бэктестов
echo "5. Логи бэктестов:"
ls -lth backtest_*.log 2>/dev/null | head -3 || echo "   Нет логов"
echo ""

echo "✅ Проверка завершена"

