# ✅ Полная настройка системы рейтинга и тестирования

## 🎯 Что сделано

### 1. ✅ Фильтрация неработающих стратегий
- Только активные стратегии показываются в рейтинге
- Неработающие стратегии автоматически отфильтрованы
- Текущие активные: `MShotStrategy`, `E0V1E_20231004_085308`

### 2. ✅ Добавлена новая стратегия
- `E0V1E_20231004_085308` - RSI + CTI + SMA стратегия
- Требует тестирования (запустите бэктест)

### 3. ✅ Создан интерфейс для запуска тестов
- Веб-интерфейс: `user_data/web/test_runner.html`
- CLI интерфейс: `strategy_test_runner.py`

## 🚀 Как использовать

### Запуск тестов стратегий

#### Через веб-интерфейс:
```
file:///home/crypto/sites/cryptotrader.com/freqtrade/user_data/web/test_runner.html
```

#### Через CLI:

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate

# Тест одной стратегии
python3 strategy_test_runner.py --strategy MShotStrategy
python3 strategy_test_runner.py --strategy E0V1E_20231004_085308

# Тест всех активных стратегий
python3 strategy_test_runner.py --all
```

### Обновление рейтинга

После запуска тестов обновите рейтинг:

```bash
# Рассчитать рейтинг
python3 strategy_rating_system_standalone.py

# Обновить веб-интерфейс
python3 rating_web_interface_standalone.py
```

### Просмотр результатов

#### Рейтинг стратегий:
```
file:///home/crypto/sites/cryptotrader.com/freqtrade/user_data/web/strategy_rankings.html
```

#### Результаты бэктестов:
```
file:///home/crypto/sites/cryptotrader.com/freqtrade/user_data/web/backtest_results.html
```

## 📋 Активные стратегии

Список активных стратегий находится в:
- `strategy_rating_system_standalone.py`
- `rating_web_interface_standalone.py`
- `strategy_test_runner.py`

Текущий список:
```python
ACTIVE_STRATEGIES = [
    "MShotStrategy",
    "E0V1E_20231004_085308",
]
```

## 🔧 Изменение списка активных стратегий

### Добавить стратегию:

1. Поместите файл в `user_data/strategies/`
2. Добавьте имя в `ACTIVE_STRATEGIES` во всех трех файлах выше
3. Запустите тест
4. Обновите рейтинг

### Убрать стратегию:

1. Удалите имя из `ACTIVE_STRATEGIES`
2. Обновите рейтинг

## 📊 Автоматический процесс

### Полный цикл тестирования:

```bash
# 1. Запустить тесты всех активных стратегий
python3 strategy_test_runner.py --all

# 2. Рассчитать рейтинг
python3 strategy_rating_system_standalone.py

# 3. Обновить веб-интерфейсы
python3 rating_web_interface_standalone.py
python3 create_custom_backtest_page.py  # если нужно
```

## 🌐 Веб-интерфейсы

1. **Рейтинг стратегий** - `strategy_rankings.html`
   - Показывает только активные стратегии
   - Сортировка по Ninja Score
   - Фильтрация неработающих

2. **Запуск тестов** - `test_runner.html`
   - Выбор стратегий для тестирования
   - Запуск всех тестов
   - Ссылки на результаты

3. **Результаты бэктестов** - `backtest_results.html`
   - Детальные результаты всех бэктестов
   - По стратегиям

## ✅ Что работает

- ✅ Фильтрация неработающих стратегий
- ✅ Показ только активных стратегий в рейтинге
- ✅ Интерфейс для запуска тестов
- ✅ Автоматический расчет рейтинга
- ✅ Веб-интерфейсы для просмотра

## 📝 Следующие шаги

1. Запустите тест новой стратегии:
   ```bash
   python3 strategy_test_runner.py --strategy E0V1E_20231004_085308
   ```

2. Если тест успешен, обновите рейтинг

3. Проверьте результаты в веб-интерфейсе



