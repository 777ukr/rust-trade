# 🔧 Исправление доступа к Backtesting

## Проблема
В веб-интерфейсе нет раздела Backtesting, только Dashboard.

## Решение

### Вариант 1: Прямой доступ к Backtesting (рекомендуется)

Откройте напрямую в браузере:
```
http://127.0.0.1:8081/backtesting
```

FreqUI должен показать раздел Backtesting даже если его нет в меню.

### Вариант 2: Перезапуск веб-сервера

1. Остановите текущий процесс:
   ```bash
   # Найдите процесс
   ps aux | grep freqtrade
   # Остановите его (Ctrl+C или kill)
   ```

2. Перезапустите с веб-интерфейсом:
   ```bash
   cd /home/crypto/sites/cryptotrader.com/freqtrade
   source .venv/bin/activate
   freqtrade trade --config ../config/freqtrade_config.json --strategy TestStrategy
   ```

3. Откройте: http://127.0.0.1:8081/backtesting

### Вариант 3: Использование API напрямую

Если веб-интерфейс не показывает Backtesting, используйте API:

```bash
# Получить список всех бэктестов
curl -u freqtrader:PASSWORD \
  http://127.0.0.1:8081/api/v1/backtest/history

# Запустить новый бэктест через API
curl -X POST -u freqtrader:PASSWORD \
  -H "Content-Type: application/json" \
  -d '{
    "strategy": "MShotStrategy",
    "timerange": "20251005-20251104",
    "timeframe": "5m",
    "pairs": ["BTC/USDT"]
  }' \
  http://127.0.0.1:8081/api/v1/backtest
```

### Вариант 4: Использование CLI для просмотра результатов

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate

# Показать результаты последнего бэктеста
freqtrade backtesting-show

# Показать конкретный результат
freqtrade backtesting-show --backtest-filename=backtest-result-2025-11-04_15-19-32.zip

# Показать рейтинг по парам
freqtrade backtesting-show --show-pair-list
```

## Проверка настройки

Убедитесь, что в `config/freqtrade_config.json`:

```json
{
  "api_server": {
    "enabled": true,
    "listen_ip_address": "127.0.0.1",
    "listen_port": 8081,
    "enable_openapi": true
  }
}
```

## Объяснение разницы

### Dashboard (что вы видите сейчас):
- Показывает **live торговлю** (текущие позиции)
- Данные в реальном времени
- Статистика активных сделок
- **НЕ показывает результаты бэктестов**

### Backtesting (что нужно):
- Показывает **результаты бэктестов** (исторические тесты)
- Графики equity curve
- Сравнение стратегий
- История всех бэктестов

## Быстрое решение

Просто откройте напрямую:
```
http://127.0.0.1:8081/backtesting
```

Если страница открывается - значит Backtesting доступен, просто не видно в меню (это может быть особенность версии FreqUI 2.1.0).

## Если не работает

1. Проверьте логи: `tail -f freqtrade.log`
2. Проверьте порт: `netstat -tuln | grep 8081`
3. Попробуйте другой браузер или режим инкогнито
4. Очистите кэш браузера (Ctrl+Shift+Delete)

