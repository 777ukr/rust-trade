#!/usr/bin/env python3
"""
Создание кастомной страницы для просмотра результатов бэктестов
Работает независимо от FreqUI, используя прямой доступ к данным
"""

import json
from pathlib import Path
from datetime import datetime
from typing import List, Dict
import zipfile

FREQTRADE_DIR = Path(__file__).parent
RESULTS_DIR = FREQTRADE_DIR / "user_data" / "backtest_results"
WEB_DIR = FREQTRADE_DIR / "user_data" / "web"


def extract_backtest_data(zip_file: Path) -> Dict:
    """Извлекает данные из ZIP файла бэктеста"""
    try:
        with zipfile.ZipFile(zip_file, 'r') as zip_ref:
            # Ищем JSON файл с результатами
            for file_name in zip_ref.namelist():
                if file_name.endswith('.json') and 'backtest' in file_name.lower():
                    data = json.loads(zip_ref.read(file_name))
                    return data
    except Exception as e:
        print(f"⚠️  Ошибка при чтении {zip_file.name}: {e}")
    return {}


def get_all_backtest_results() -> List[Dict]:
    """Получает все результаты бэктестов"""
    results = []
    
    for zip_file in sorted(RESULTS_DIR.glob("*.zip"), key=lambda x: x.stat().st_mtime, reverse=True):
        meta_file = zip_file.with_suffix(".meta.json")
        
        if not meta_file.exists():
            continue
        
        try:
            meta_data = json.loads(meta_file.read_text())
            strategy_name = list(meta_data.keys())[0] if meta_data else "Unknown"
            
            # Извлекаем данные из ZIP
            backtest_data = extract_backtest_data(zip_file)
            
            # Получаем статистику
            stats = {}
            if backtest_data:
                strategy_results = backtest_data.get(strategy_name, {})
                if isinstance(strategy_results, dict):
                    stats = strategy_results.get("results", {})
            
            result = {
                "filename": zip_file.name,
                "strategy": strategy_name,
                "created_at": datetime.fromtimestamp(zip_file.stat().st_mtime).isoformat(),
                "size_kb": zip_file.stat().st_size / 1024,
                "stats": stats,
                "meta": meta_data.get(strategy_name, {}) if meta_data else {}
            }
            
            results.append(result)
        except Exception as e:
            print(f"⚠️  Ошибка при обработке {zip_file.name}: {e}")
    
    return results


def create_interactive_backtest_page(results: List[Dict]):
    """Создает интерактивную HTML страницу с результатами"""
    WEB_DIR.mkdir(parents=True, exist_ok=True)
    
    # Сортируем по стратегии и дате
    results_by_strategy = {}
    for result in results:
        strategy = result["strategy"]
        if strategy not in results_by_strategy:
            results_by_strategy[strategy] = []
        results_by_strategy[strategy].append(result)
    
    html = """<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Freqtrade Backtest Results</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        .header {
            background: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .header h1 {
            color: #333;
            margin-bottom: 10px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }
        .stat-card h3 {
            font-size: 14px;
            opacity: 0.9;
            margin-bottom: 10px;
        }
        .stat-card .value {
            font-size: 32px;
            font-weight: bold;
        }
        .strategy-section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .strategy-section h2 {
            color: #4CAF50;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #4CAF50;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th {
            background: #4CAF50;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }
        tr:hover {
            background: #f9f9f9;
        }
        .positive { color: #4CAF50; font-weight: bold; }
        .negative { color: #f44336; font-weight: bold; }
        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }
        .badge-success { background: #4CAF50; color: white; }
        .badge-info { background: #2196F3; color: white; }
        .badge-warning { background: #ff9800; color: white; }
        .btn {
            display: inline-block;
            padding: 8px 16px;
            background: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 2px;
            font-size: 12px;
        }
        .btn:hover { background: #45a049; }
        .btn-secondary {
            background: #2196F3;
        }
        .btn-secondary:hover { background: #0b7dda; }
        .alert {
            padding: 15px;
            background: #fff3cd;
            border: 1px solid #ffc107;
            border-radius: 5px;
            margin: 20px 0;
        }
        .loading {
            text-align: center;
            padding: 40px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Freqtrade Backtest Results</h1>
            <p>Результаты тестирования всех стратегий</p>
            <div style="margin-top: 15px;">
                <a href="http://127.0.0.1:8081/backtesting" class="btn btn-secondary" target="_blank">FreqUI Backtesting</a>
                <a href="http://127.0.0.1:8081/dashboard" class="btn" target="_blank">Dashboard</a>
            </div>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Всего бэктестов</h3>
                <div class="value">""" + str(len(results)) + """</div>
            </div>
            <div class="stat-card">
                <h3>Стратегий</h3>
                <div class="value">""" + str(len(results_by_strategy)) + """</div>
            </div>
            <div class="stat-card">
                <h3>Последний тест</h3>
                <div class="value" style="font-size: 18px;">""" + (results[0]["created_at"][:10] if results else "N/A") + """</div>
            </div>
        </div>
"""
    
    # Добавляем результаты по стратегиям
    for strategy, strategy_results in sorted(results_by_strategy.items()):
        html += f"""
        <div class="strategy-section">
            <h2>📈 {strategy}</h2>
            <p><strong>Бэктестов:</strong> {len(strategy_results)}</p>
            
            <table>
                <thead>
                    <tr>
                        <th>Дата</th>
                        <th>Файл</th>
                        <th>Размер</th>
                        <th>Сделок</th>
                        <th>PNL %</th>
                        <th>Win Rate</th>
                        <th>Profit Factor</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
"""
        
        for result in strategy_results:
            stats = result.get("stats", {})
            trades = stats.get("total_trades", 0) if stats else 0
            profit_pct = stats.get("profit_total_pct", 0.0) if stats else 0.0
            win_rate = stats.get("winrate", 0.0) if stats else 0.0
            profit_factor = stats.get("profit_factor", 0.0) if stats else 0.0
            
            created_date = result["created_at"][:10]
            filename = result["filename"]
            size_kb = result["size_kb"]
            
            profit_class = "positive" if profit_pct >= 0 else "negative"
            
            html += f"""
                    <tr>
                        <td>{created_date}</td>
                        <td><code style="font-size: 11px;">{filename[:50]}...</code></td>
                        <td>{size_kb:.1f} KB</td>
                        <td>{trades}</td>
                        <td class="{profit_class}">{profit_pct:+.2f}%</td>
                        <td>{win_rate:.1f}%</td>
                        <td>{profit_factor:.2f}</td>
                        <td>
                            <a href="http://127.0.0.1:8081/api/v1/backtest/history/result?filename={filename}&strategy={strategy}" 
                               class="btn" target="_blank">API</a>
                            <button onclick="showDetails('{filename}', '{strategy}')" class="btn btn-secondary">Детали</button>
                        </td>
                    </tr>
"""
        
        html += """
                </tbody>
            </table>
        </div>
"""
    
    html += """
        <div class="alert">
            <strong>💡 Инструкция:</strong>
            <ul style="margin: 10px 0 0 20px;">
                <li>Если FreqUI Backtesting не работает - используйте эту страницу</li>
                <li>Для детального просмотра используйте CLI: <code>freqtrade backtesting-show</code></li>
                <li>Для запуска новых тестов: <code>python3 run_full_backtest_suite.py</code></li>
            </ul>
        </div>
    </div>
    
    <script>
        function showDetails(filename, strategy) {
            alert('Файл: ' + filename + '\\nСтратегия: ' + strategy + '\\n\\nИспользуйте CLI для детального просмотра:\\nfreqtrade backtesting-show --backtest-filename=' + filename);
        }
        
        // Автообновление каждые 30 секунд
        setTimeout(function() {
            location.reload();
        }, 30000);
    </script>
</body>
</html>
"""
    
    html_file = WEB_DIR / "backtest_results.html"
    html_file.write_text(html, encoding='utf-8')
    
    print(f"✅ Интерактивная страница создана: {html_file}")
    return html_file


def main():
    """Главная функция"""
    print("🎨 Создание кастомной страницы для просмотра результатов\n")
    
    results = get_all_backtest_results()
    
    if not results:
        print("❌ Нет результатов для отображения")
        print("💡 Запустите: python3 run_full_backtest_suite.py")
        return
    
    print(f"📊 Найдено результатов: {len(results)}")
    
    html_file = create_interactive_backtest_page(results)
    
    print(f"\n{'='*70}")
    print("✅ Кастомная страница создана!")
    print(f"{'='*70}\n")
    print(f"🌐 Откройте в браузере:")
    print(f"   file://{html_file.absolute()}")
    print(f"\n💡 Или через веб-сервер:")
    print(f"   http://127.0.0.1:8081/backtesting")
    print(f"   (если FreqUI работает)")


if __name__ == "__main__":
    main()



