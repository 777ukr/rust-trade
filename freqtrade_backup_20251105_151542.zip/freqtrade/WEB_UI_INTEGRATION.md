# 🌐 Интеграция с Freqtrade Web UI

## Быстрый доступ к результатам

### Прямые ссылки:

1. **Страница Backtesting (основная):**
   ```
   http://127.0.0.1:8081/backtesting
   ```

2. **API для получения истории бэктестов:**
   ```
   http://127.0.0.1:8081/api/v1/backtest/history
   ```

3. **API для конкретного результата:**
   ```
   http://127.0.0.1:8081/api/v1/backtest/history/result?filename=backtest_results_YYYYMMDD_HHMMSS.json&strategy=StrategyName
   ```

## Как использовать

### Вариант 1: Через веб-интерфейс (рекомендуется)

1. **Запустите интеграцию:**
   ```bash
   cd /home/crypto/sites/cryptotrader.com/freqtrade
   source .venv/bin/activate
   python3 integrate_with_webui.py
   ```

2. **Откройте браузер:**
   ```
   http://127.0.0.1:8081/backtesting
   ```

3. **Войдите:**
   - Логин: `freqtrader`
   - Пароль: см. `config/freqtrade_config.json` (секция `api_server.password`)

4. **Результаты автоматически появятся в разделе Backtesting**

### Вариант 2: Через API

```bash
# Получить список всех бэктестов
curl -u freqtrader:PASSWORD \
  http://127.0.0.1:8081/api/v1/backtest/history

# Получить конкретный результат
curl -u freqtrader:PASSWORD \
  "http://127.0.0.1:8081/api/v1/backtest/history/result?filename=backtest_results_20251104_153000.json&strategy=MShotStrategy"
```

## Структура результатов

Freqtrade автоматически создает JSON файлы с метаданными:
```
user_data/backtest_results/
  ├── backtest_results_20251104_153000.json  (метаданные)
  ├── backtest_results_20251104_153000_trades.csv  (детальные сделки)
  └── index.json  (индекс всех результатов)
```

## Формат данных

### JSON файл содержит:
- `metadata` - метаданные бэктеста
- `strategy` - информация о стратегии
- `strategy_comparison` - сравнение стратегий
- `results` - результаты бэктеста

### CSV файл содержит:
- `open_date` - дата входа
- `close_date` - дата выхода
- `profit_abs` - абсолютная прибыль
- `profit_ratio` - прибыль в долях
- `profit_pct` - прибыль в процентах
- `duration` - длительность сделки

## Навигация в веб-интерфейсе

### Главное меню:
- **Dashboard** - текущие позиции (live торговля)
- **Backtesting** - результаты бэктестов ⭐
- **Trades** - история всех сделок
- **Settings** - настройки

### В разделе Backtesting:
- **Run Backtest** - запустить новый бэктест
- **Backtest History** - история всех бэктестов
- **Results** - детальные результаты
- **Graphs** - графики equity curve

## Автоматизация

### Скрипт для регулярного тестирования:

```bash
#!/bin/bash
# test_strategies.sh

cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate

# Запустить тестирование всех стратегий
python3 integrate_with_webui.py

# Результаты автоматически появятся в веб-интерфейсе
echo "✅ Результаты доступны: http://127.0.0.1:8081/backtesting"
```

### Добавить в cron (ежедневное тестирование):

```bash
# Каждый день в 00:00
0 0 * * * cd /home/crypto/sites/cryptotrader.com/freqtrade && source .venv/bin/activate && python3 integrate_with_webui.py
```

## Troubleshooting

### Проблема: "Unauthorized" при обращении к API
**Решение:** Проверьте логин и пароль в `config/freqtrade_config.json`

### Проблема: Результаты не отображаются
**Решение:** 
1. Убедитесь, что веб-сервер запущен: `freqtrade webserver` или `freqtrade trade`
2. Проверьте, что JSON файлы созданы в `user_data/backtest_results/`
3. Обновите страницу в браузере

### Проблема: Страница не открывается
**Решение:**
1. Проверьте, что порт 8081 открыт: `netstat -tuln | grep 8081`
2. Проверьте логи: `tail -f freqtrade.log`
3. Убедитесь, что веб-сервер включен в конфиге

## Ссылки на документацию

- [Freqtrade Web UI Documentation](https://www.freqtrade.io/en/latest/webserver/)
- [Backtesting API](https://www.freqtrade.io/en/latest/rest-api/#backtesting-api)

