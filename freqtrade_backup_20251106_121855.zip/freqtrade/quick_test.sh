#!/bin/bash
# Быстрый скрипт для тестирования стратегий

cd "$(dirname "$0")"
source .venv/bin/activate

echo "🚀 Быстрый тест стратегий Freqtrade"
echo ""

# Проверяем наличие данных
DATA_DIR="user_data/data/gateio"
if [ ! -d "$DATA_DIR" ]; then
    echo "📥 Данные не найдены. Загружаем..."
    # Gate.io ограничивает до 10000 точек (≈34 дня для 5m)
    freqtrade download-data \
        --exchange gateio \
        --pairs BTC/USDT \
        --timeframes 5m \
        --days 30 \
        --config ../config/freqtrade_config.json
fi

echo ""
echo "🧪 Тестируем MShotStrategy..."
# Вычисляем даты для последних 30 дней
END_DATE=$(date +%Y%m%d)
START_DATE=$(date -d "30 days ago" +%Y%m%d)

freqtrade backtesting \
    --config ../config/freqtrade_config.json \
    --strategy MShotStrategy \
    --timerange ${START_DATE}-${END_DATE} \
    --timeframe 5m \
    --pairs BTC/USDT \
    --export trades \
    --breakdown month

echo ""
echo "🧪 Тестируем AdvancedIndicatorStrategy..."
freqtrade backtesting \
    --config ../config/freqtrade_config.json \
    --strategy AdvancedIndicatorStrategy \
    --timerange ${START_DATE}-${END_DATE} \
    --timeframe 5m \
    --pairs BTC/USDT \
    --export trades \
    --breakdown month

echo ""
echo "✅ Тестирование завершено!"
echo "📊 Результаты сохранены в user_data/backtest_results/"

