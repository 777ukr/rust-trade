#!/bin/bash
# Скрипт для быстрого доступа к Backtesting

echo "🔍 Проверка доступа к Backtesting..."
echo ""

WEB_URL="http://127.0.0.1:8081"
BACKTEST_URL="${WEB_URL}/backtesting"

echo "📊 Прямые ссылки:"
echo "   Backtesting: ${BACKTEST_URL}"
echo "   Dashboard: ${WEB_URL}/dashboard"
echo "   API: ${WEB_URL}/api/v1/backtest/history"
echo ""

# Проверяем доступность
if curl -s -o /dev/null -w "%{http_code}" "${WEB_URL}" | grep -q "200\|401"; then
    echo "✅ Веб-сервер доступен"
    
    # Проверяем Backtesting
    BACKTEST_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "${BACKTEST_URL}")
    if [ "$BACKTEST_STATUS" = "200" ] || [ "$BACKTEST_STATUS" = "401" ]; then
        echo "✅ Backtesting доступен!"
        echo ""
        echo "🌐 Открываю в браузере..."
        
        if command -v xdg-open &> /dev/null; then
            xdg-open "${BACKTEST_URL}"
        elif command -v open &> /dev/null; then
            open "${BACKTEST_URL}"
        else
            echo "📋 Откройте вручную: ${BACKTEST_URL}"
        fi
    else
        echo "⚠️  Backtesting недоступен (код: ${BACKTEST_STATUS})"
        echo "💡 Попробуйте:"
        echo "   1. Перезапустить freqtrade"
        echo "   2. Проверить конфиг: api_server.enabled: true"
        echo "   3. Использовать CLI: freqtrade backtesting-show"
    fi
else
    echo "❌ Веб-сервер недоступен"
    echo "💡 Запустите: freqtrade trade --config ../config/freqtrade_config.json"
fi

echo ""
echo "📝 Инструкции:"
echo "   - Логин: freqtrader"
echo "   - Пароль: см. config/freqtrade_config.json"
echo "   - Если нет в меню - откройте напрямую: ${BACKTEST_URL}"

