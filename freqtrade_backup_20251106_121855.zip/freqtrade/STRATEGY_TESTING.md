# Тестирование и Рейтинг Стратегий

## 📋 Описание

Система автоматического тестирования стратегий из Rust проекта на Freqtrade с составлением рейтинга.

## 🎯 Созданные стратегии

### 1. MShotStrategy
**Источник:** `src/strategy/moon_strategies/mshot.rs`

**Особенности:**
- Переставление buy ордеров в коридоре цен
- Ловит прострелы и автоматически переставляет ордер
- Поддержка дельт (3h, 1h, 15m)
- Настраиваемые параметры через Hyperopt

**Параметры:**
- `mshot_price`: % от текущей цены для buy ордера (по умолчанию 10%)
- `mshot_price_min`: Мин. % когда переставлять ордер (по умолчанию 7%)
- `sell_price`: Цена продажи в % (по умолчанию 1.35%)

### 2. AdvancedIndicatorStrategy
**Источник:** Стратегия с hash `83badbcc97221e69320c2c680455cddc9065bde29048fff1ffb467350cd79510`

**Особенности:**
- Множество технических индикаторов (40+)
- VWAP, RSI (fast, RMI, MFI)
- Donchian Channels, Bollinger Bands
- Ichimoku (Senkou Span A/B)
- Трендовые индикаторы (4h, 15m, 6h)
- Volume анализ

**Параметры:**
- `stoploss`: -0.11
- `timeframe`: 5m

## 🚀 Использование

### Шаг 1: Загрузка исторических данных

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate

# Загрузить данные для Gate.io
freqtrade download-data \
  --exchange gateio \
  --pairs BTC/USDT ETH/USDT SOL/USDT \
  --timeframes 5m 15m 4h 6h \
  --timerange 20240101-20241201
```

### Шаг 2: Тестирование одной стратегии

```bash
# Тест MShot стратегии
freqtrade backtesting \
  --config ../config/freqtrade_config.json \
  --strategy MShotStrategy \
  --timerange 20240101-20241201 \
  --timeframe 5m \
  --pairs BTC/USDT \
  --export trades

# Тест Advanced Indicator стратегии
freqtrade backtesting \
  --config ../config/freqtrade_config.json \
  --strategy AdvancedIndicatorStrategy \
  --timerange 20240101-20241201 \
  --timeframe 5m \
  --pairs BTC/USDT \
  --export trades
```

### Шаг 3: Автоматическое тестирование всех стратегий

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate
python test_and_rank_strategies.py
```

Скрипт автоматически:
1. Находит все стратегии в `user_data/strategies/`
2. Тестирует каждую на всех парах (BTC/USDT, ETH/USDT, SOL/USDT)
3. Вычисляет метрики и рейтинг
4. Сохраняет результаты в JSON
5. Выводит рейтинг в консоль

## 📊 Система рейтинга

Рейтинг вычисляется на основе 4 компонентов:

### 1. Profitability Score (0-10) - 35%
- P&L (40%)
- Profit Factor (30%)
- Win Rate (30%)

### 2. Stability Score (0-10) - 25%
- Количество сделок (чем больше, тем стабильнее)

### 3. Risk Score (0-10) - 25%
- Обратный к Max Drawdown (меньше drawdown = больше score)

### 4. Fill Rate Score (0-10) - 15%
- Процент исполненных ордеров

### Overall Rating
Средневзвешенное всех компонентов (0-10)

### Stars (0-5)
- 5 звезд: rating >= 9.0
- 4 звезды: rating >= 8.0
- 3 звезды: rating >= 7.0
- 2 звезды: rating >= 6.0
- 1 звезда: rating >= 5.0
- 0 звезд: rating < 5.0

## 📁 Структура результатов

Результаты сохраняются в:
```
freqtrade/user_data/backtest_results/
  ├── strategy_rankings_YYYYMMDD_HHMMSS.json
  └── {strategy}_{pair}_trades.csv
```

### Формат JSON результата:
```json
{
  "strategy": "MShotStrategy",
  "pair": "BTC/USDT",
  "total_trades": 150,
  "winning_trades": 90,
  "losing_trades": 60,
  "total_profit": 1250.50,
  "profit_pct": 12.5,
  "max_drawdown": 5.2,
  "profit_factor": 2.1,
  "win_rate": 60.0,
  "sharpe_ratio": 1.8,
  "avg_trade_duration": 45.2,
  "profitability_score": 7.5,
  "stability_score": 8.0,
  "risk_score": 7.4,
  "fill_rate_score": 6.0,
  "overall_rating": 7.5,
  "stars": 3
}
```

## 🔧 Настройка

Отредактируйте `test_and_rank_strategies.py`:

```python
# Параметры бэктеста
TIMERANGE = "20240101-20241201"  # Период данных
TIMEFRAME = "5m"                  # Таймфрейм
EXCHANGE = "gateio"               # Биржа
PAIRS = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]  # Пары для тестирования
```

## 📈 Сравнение с Rust версией

После тестирования в Freqtrade можно сравнить результаты с Rust бэктестером:

1. **Метрики должны быть близки** (с учетом различий в execution engine)
2. **PnL должен быть сопоставим** (разница может быть из-за проскальзывания)
3. **Win Rate должен быть близок** (если логика стратегии идентична)

## 🎯 Следующие шаги

1. ✅ Протестировать MShot стратегию
2. ✅ Протестировать Advanced Indicator стратегию
3. 🔄 Добавить больше стратегий из Rust проекта
4. 🔄 Интеграция с barter-rs для симуляции
5. 🔄 Экспорт результатов в базу данных

## 💡 Советы

- **Начните с малого периода** (например, 1 месяц) для быстрой проверки
- **Используйте Hyperopt** для оптимизации параметров стратегий
- **Сравнивайте результаты** на разных парах для оценки универсальности
- **Анализируйте equity curve** для понимания стабильности стратегии

## 📚 Дополнительные ресурсы

- [Freqtrade Documentation](https://www.freqtrade.io/)
- [Freqtrade Strategy Customization](https://www.freqtrade.io/en/latest/strategy-customization/)
- Rust стратегии: `src/strategy/moon_strategies/`

