# 🔍 Отладка бэктестов

## Проблема: бэктест запущен, но результатов нет

### Проверка статуса

```bash
# 1. Проверить активные процессы
./check_backtest_status.sh

# 2. Проверить прогресс через API
curl http://localhost:8889/api/backtest/progress

# 3. Проверить логи API сервера
tail -f api_server.log | grep -i backtest

# 4. Проверить логи бэктестов
ls -lth backtest_*.log
tail -f backtest_*.log
```

## Возможные причины

### 1. Бэктест еще выполняется
- Проверьте: `curl http://localhost:8889/api/backtest/progress`
- Если `active_processes > 0` - бэктест выполняется

### 2. Ошибка выполнения
- Проверьте логи: `tail -50 api_server.log`
- Проверьте логи бэктеста: `tail -50 backtest_*.log`

### 3. Файлы не сохраняются
- Проверьте права: `ls -la user_data/backtest_results/`
- Проверьте место: `df -h user_data/backtest_results/`

### 4. Freqtrade не найден
- Проверьте: `which freqtrade`
- Проверьте: `freqtrade --version`

## Решение

### Автоматическое обновление рейтинга

После завершения бэктеста система автоматически:
1. Сохраняет результаты
2. Обновляет рейтинг (JSON или PostgreSQL)
3. Показывает уведомление в интерфейсе

### Ручное обновление

```bash
# Обновить рейтинг вручную
python3 strategy_rating_system_standalone.py

# Или через скрипт
./auto_update_ratings.sh
```

## Мониторинг в реальном времени

```bash
# Следить за логами
tail -f api_server.log

# Следить за новыми файлами
watch -n 5 'ls -lth user_data/backtest_results/*.zip | head -5'
```

## API Endpoints для мониторинга

- `GET /api/backtest/progress` - прогресс выполнения
- `GET /api/backtest/status` - статус последних бэктестов
- `GET /api/stats` - общая статистика

