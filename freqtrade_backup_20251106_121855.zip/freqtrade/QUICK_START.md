# 🚀 Быстрый старт системы рейтинга стратегий

## Проблема: "Не работает"

Если система не работает, выполните следующие шаги:

## 1️⃣ Установка зависимостей

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
pip3 install -r requirements_rating.txt
```

Или вручную:
```bash
pip3 install fastapi uvicorn psycopg2-binary pandas numpy pydantic python-multipart
```

## 2️⃣ Запуск API сервера

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
./start_rating_server.sh
```

Или вручную:
```bash
python3 -m uvicorn rating_api_server:app --host 0.0.0.0 --port 8889 --reload
```

## 3️⃣ Проверка работы

Откройте в браузере:
- **Главная страница**: http://localhost:8889/
- **API статистика**: http://localhost:8889/api/stats
- **API стратегии**: http://localhost:8889/api/strategies

## 4️⃣ Если нет данных для графиков

Запустите бэктест:
```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
freqtrade backtesting --strategy AdvancedIndicatorStrategy --pairs BTC/USDT --timeframe 5m
```

Или используйте скрипт:
```bash
./fix_all_for_btc_usdt.sh
```

## 5️⃣ Настройка PostgreSQL (опционально)

Если хотите использовать PostgreSQL вместо JSON:

```bash
./setup_postgresql.sh
```

## 🔍 Диагностика проблем

### Проблема: "ModuleNotFoundError: No module named 'fastapi'"
**Решение**: Установите зависимости (шаг 1)

### Проблема: "Порт 8889 уже занят"
**Решение**: 
```bash
# Найти процесс
lsof -i :8889
# Остановить процесс
kill -9 <PID>
```

### Проблема: "No backtest data found"
**Решение**: Запустите бэктест (шаг 4)

### Проблема: "PostgreSQL недоступен"
**Решение**: Это нормально, система использует JSON fallback. Если нужен PostgreSQL, настройте его (шаг 5)

## ✅ Проверка статуса

```bash
# Проверка API
curl http://localhost:8889/api/stats

# Проверка процессов
ps aux | grep uvicorn

# Проверка логов
tail -f api_server.log
```

## 📝 Примечания

- API сервер должен быть запущен постоянно для работы веб-интерфейса
- Для production используйте systemd или supervisor для автозапуска
- Логи сохраняются в `api_server.log`
