#!/bin/bash
# Проверка статуса API сервера

echo "🔍 Проверка API сервера..."
echo ""

# Проверка локального доступа
echo "1️⃣  Локальный доступ (localhost:8889):"
if curl -s http://localhost:8889/api/strategies > /dev/null 2>&1; then
    echo "   ✅ Сервер работает"
    curl -s http://localhost:8889/api/stats | python3 -m json.tool 2>/dev/null | head -5
else
    echo "   ❌ Сервер не отвечает"
fi

echo ""
echo "2️⃣  Проверка процесса:"
PROCESS=$(ps aux | grep "rating_api_server" | grep -v grep | head -1)
if [ -n "$PROCESS" ]; then
    echo "   ✅ Процесс запущен:"
    echo "   $PROCESS" | awk '{print "   PID:", $2, "| CPU:", $3"%", "| MEM:", $4"%"}'
else
    echo "   ❌ Процесс не найден"
fi

echo ""
echo "3️⃣  Проверка порта:"
if netstat -tlnp 2>/dev/null | grep 8889 > /dev/null || ss -tlnp 2>/dev/null | grep 8889 > /dev/null; then
    echo "   ✅ Порт 8889 слушается"
    netstat -tlnp 2>/dev/null | grep 8889 || ss -tlnp 2>/dev/null | grep 8889
else
    echo "   ❌ Порт 8889 не слушается"
fi

echo ""
echo "4️⃣  Внешний доступ:"
EXTERNAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}' || ip addr show | grep "inet " | grep -v "127.0.0.1" | head -1 | awk '{print $2}' | cut -d/ -f1)
if [ -n "$EXTERNAL_IP" ]; then
    echo "   Ваш IP: $EXTERNAL_IP"
    echo "   Попробуйте: http://$EXTERNAL_IP:8889"
else
    echo "   Не удалось определить внешний IP"
fi

echo ""
echo "5️⃣  Проверка логов (последние 5 строк):"
if [ -f "api_server.log" ]; then
    tail -5 api_server.log 2>/dev/null | sed 's/^/   /'
else
    echo "   Лог файл не найден"
fi

echo ""
echo "📝 Если сервер не работает, запустите:"
echo "   bash start_api_server.sh"
echo ""
echo "🌐 Если вы подключаетесь с другого компьютера:"
echo "   1. Используйте IP сервера вместо localhost"
echo "   2. Проверьте firewall (порт 8889 должен быть открыт)"
echo "   3. Убедитесь, что сервер слушает 0.0.0.0 (а не только 127.0.0.1)"
