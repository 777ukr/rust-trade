# 🚀 Быстрый доступ к Freqtrade

## 🌐 Веб-интерфейс Freqtrade

### Доступ к Freqtrade Web UI:
- **URL:** http://localhost:8081 (или http://127.0.0.1:8081)
- **Username:** `freqtrader`
- **Password:** см. `config/freqtrade_config.json` (секция `api_server.password`)

### Основные страницы:
- **Dashboard:** http://localhost:8081/dashboard - Live торговля
- **Backtesting:** http://localhost:8081/backtesting - Результаты бэктестов
- **Trades:** http://localhost:8081/trades - История сделок

## 📊 Рейтинг стратегий (Ninja Style)

### Открыть рейтинг:
```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
xdg-open user_data/web/strategy_rankings.html
```

Или напрямую в браузере:
```
file:///home/crypto/sites/cryptotrader.com/freqtrade/user_data/web/strategy_rankings.html
```

### Обновить рейтинг:
```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate
python3 strategy_rating_system_standalone.py
python3 rating_web_interface_standalone.py
```

## 🔧 Команды Freqtrade

### Активация окружения:
```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate
```

### Основные команды:
```bash
# Запуск торговли
freqtrade trade --config ../config/freqtrade_config.json --strategy TestStrategy

# Запуск бэктестов
freqtrade backtesting --config ../config/freqtrade_config.json --strategy MShotStrategy

# Просмотр результатов
freqtrade backtesting-show

# Список стратегий
freqtrade list-strategies
```

## ✅ Проверка работоспособности

### 1. Проверить что Freqtrade установлен:
```bash
cd freqtrade
source .venv/bin/activate
freqtrade --version
```

### 2. Проверить веб-сервер:
```bash
curl http://localhost:8081/api/v1/ping
```

### 3. Проверить результаты бэктестов:
```bash
ls -lh user_data/backtest_results/*.zip | wc -l
```

### 4. Проверить рейтинг:
```bash
ls -lh user_data/ratings/rankings.json
```

## 📝 Примечания

- ✅ Система рейтинга **НЕ изменяет** существующий Freqtrade
- ✅ Все файлы рейтинга в отдельной директории `user_data/ratings/`
- ✅ Веб-интерфейс рейтинга - отдельный HTML файл
- ✅ Freqtrade работает независимо от системы рейтинга

## 🔗 Полезные ссылки

- **Freqtrade документация:** https://www.freqtrade.io/
- **Freqtrade GitHub:** https://github.com/freqtrade/freqtrade
- **Ninja.trade (референс):** https://ninja.trade/



