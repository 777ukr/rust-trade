#!/usr/bin/env python3
"""
API для статуса бэктестов
"""

import json
from pathlib import Path
from datetime import datetime
from fastapi import APIRouter

router = APIRouter()

RESULTS_DIR = Path(__file__).parent / "user_data" / "backtest_results"

@router.get("/api/backtest/status")
async def get_backtest_status():
    """Получить статус последних бэктестов"""
    try:
        # Ищем последние ZIP файлы результатов
        zip_files = sorted(RESULTS_DIR.glob("*.zip"), key=lambda x: x.stat().st_mtime, reverse=True)
        
        statuses = []
        for zip_file in zip_files[:10]:  # Последние 10
            mtime = datetime.fromtimestamp(zip_file.stat().st_mtime)
            statuses.append({
                "file": zip_file.name,
                "modified": mtime.isoformat(),
                "size": zip_file.stat().st_size
            })
        
        return {
            "recent_backtests": statuses,
            "total": len(zip_files)
        }
    except Exception as e:
        return {"error": str(e), "recent_backtests": [], "total": 0}

