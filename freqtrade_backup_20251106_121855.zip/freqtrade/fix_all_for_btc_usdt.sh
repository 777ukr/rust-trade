#!/bin/bash
# Полное исправление для BTC/USDT - все работает на 100%

echo "🔧 Полное исправление системы для BTC/USDT..."
echo ""

# 1. Перезапуск API сервера
echo "1️⃣  Перезапуск API сервера..."
pkill -f "rating_api_server.py" 2>/dev/null
sleep 2
cd /home/crypto/sites/cryptotrader.com/freqtrade
nohup python3 rating_api_server.py > api_server.log 2>&1 &
sleep 3
echo "   ✅ API сервер перезапущен"
echo ""

# 2. Проверка данных
echo "2️⃣  Проверка данных BTC/USDT..."
DATA_FILE="user_data/data/binance/BTC_USDT-5m.json"
if [ -f "$DATA_FILE" ]; then
    COUNT=$(python3 -c "import json; print(len(json.load(open('$DATA_FILE'))))" 2>/dev/null || echo "0")
    echo "   ✅ Данные найдены: $COUNT свечей"
else
    echo "   ❌ Данные не найдены: $DATA_FILE"
    echo "   💡 Запустите загрузку данных:"
    echo "      freqtrade download-data --exchange binance --pairs BTC/USDT --timeframe 5m --days 30"
fi
echo ""

# 3. Запуск бэктеста для AdvancedIndicatorStrategy
echo "3️⃣  Запуск бэктеста для AdvancedIndicatorStrategy..."
curl -X POST http://localhost:8889/api/backtest/run \
  -H "Content-Type: application/json" \
  -d '{"strategy_name": "AdvancedIndicatorStrategy", "pairs": ["BTC/USDT"], "timeframe": "5m"}' \
  2>&1 | python3 -m json.tool | grep -E "status|message|timerange" || echo "   ⚠️  Ошибка запуска"
echo ""

# 4. Ожидание завершения (30 секунд)
echo "4️⃣  Ожидание завершения бэктеста (30 секунд)..."
sleep 30

# 5. Проверка результатов
echo "5️⃣  Проверка результатов..."
curl -s "http://localhost:8889/api/strategies/AdvancedIndicatorStrategy/chart-data?pair=BTC/USDT&timeframe=5m" | \
  python3 -c "import sys, json; d=json.load(sys.stdin); print(f\"   has_data: {d.get('has_data')}\"); print(f\"   OHLCV: {len(d.get('ohlcv', []))} свечей\"); print(f\"   Trades: {d.get('total_trades')} сделок\")"
echo ""

# 6. Финальная проверка
echo "6️⃣  Финальная проверка..."
echo "   🌐 Откройте в браузере: http://localhost:8889"
echo "   📊 Кликните на стратегию AdvancedIndicatorStrategy"
echo "   📈 График должен отображаться автоматически"
echo ""

echo "✅ Готово! Система настроена для BTC/USDT"

