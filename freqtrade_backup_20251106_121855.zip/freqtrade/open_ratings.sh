#!/bin/bash
# Скрипт для открытия рейтинга стратегий в браузере

cd "$(dirname "$0")"

echo "🌐 Открытие рейтинга стратегий..."
echo ""

# Проверяем наличие файлов
RATINGS_HTML="user_data/web/strategy_rankings.html"
BACKTEST_HTML="user_data/web/backtest_results.html"

if [ -f "$RATINGS_HTML" ]; then
    echo "✅ Найден файл рейтинга: $RATINGS_HTML"
    echo ""
    echo "📋 Способы открытия:"
    echo ""
    echo "1️⃣  Прямой путь (скопируйте в адресную строку браузера):"
    echo "   file://$(pwd)/$RATINGS_HTML"
    echo ""
    echo "2️⃣  Через веб-сервер (запустите в отдельном терминале):"
    echo "   cd $(pwd)"
    echo "   python3 -m http.server 8888 --directory user_data/web"
    echo "   Затем откройте: http://localhost:8888/strategy_rankings.html"
    echo ""
    
    # Попытка открыть автоматически
    if command -v xdg-open &> /dev/null; then
        echo "🚀 Автоматическое открытие..."
        xdg-open "file://$(pwd)/$RATINGS_HTML" 2>/dev/null
    elif command -v gnome-open &> /dev/null; then
        gnome-open "file://$(pwd)/$RATINGS_HTML" 2>/dev/null
    elif command -v open &> /dev/null; then
        open "file://$(pwd)/$RATINGS_HTML" 2>/dev/null
    else
        echo "⚠️  Автоматическое открытие недоступно"
        echo "   Скопируйте путь выше в браузер"
    fi
else
    echo "❌ Файл рейтинга не найден: $RATINGS_HTML"
    echo "💡 Создайте рейтинг: python3 strategy_rating_system_standalone.py && python3 rating_web_interface_standalone.py"
fi

if [ -f "$BACKTEST_HTML" ]; then
    echo ""
    echo "📊 Также доступен файл результатов бэктестов:"
    echo "   file://$(pwd)/$BACKTEST_HTML"
fi



