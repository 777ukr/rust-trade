#!/bin/bash
# Скрипт для установки системы рейтинга стратегий

set -e

echo "🚀 Установка системы рейтинга стратегий..."
echo ""

# Проверка переменных окружения
if [ -z "$DATABASE_URL" ]; then
    echo "⚠️  DATABASE_URL не установлена"
    echo "💡 Используйте: export DATABASE_URL='postgresql://user:pass@localhost:5432/cryptotrader'"
    DATABASE_URL="postgresql://postgres:postgres@localhost:5432/cryptotrader"
    echo "   Используется значение по умолчанию: $DATABASE_URL"
fi

# Переходим в директорию проекта
cd "$(dirname "$0")/.."

# Проверка наличия PostgreSQL
if ! command -v psql &> /dev/null; then
    echo "❌ PostgreSQL не установлен"
    echo "💡 Установите: sudo apt-get install postgresql postgresql-contrib"
    exit 1
fi

# Создание базы данных (если не существует)
echo "📊 Проверка базы данных..."
psql -U postgres -c "SELECT 1 FROM pg_database WHERE datname='cryptotrader'" | grep -q 1 || \
    psql -U postgres -c "CREATE DATABASE cryptotrader;"

# Применение схемы
echo "📋 Применение схемы рейтинга..."
psql "$DATABASE_URL" -f database/strategy_rating_schema.sql

# Установка Python зависимостей
echo "📦 Установка Python зависимостей..."
cd freqtrade
source .venv/bin/activate 2>/dev/null || python3 -m venv .venv && source .venv/bin/activate

pip install psycopg2-binary --quiet || pip install psycopg2-binary

echo ""
echo "✅ Установка завершена!"
echo ""
echo "📝 Следующие шаги:"
echo "   1. Запустите бэктесты: python3 run_full_backtest_suite.py"
echo "   2. Рассчитайте рейтинг: python3 strategy_rating_system.py"
echo "   3. Создайте веб-интерфейс: python3 rating_web_interface.py"
echo "   4. Откройте: user_data/web/strategy_rankings.html"



