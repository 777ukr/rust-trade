#!/bin/bash
# Полная настройка и тестирование системы

set -e

cd "$(dirname "$0")"

echo "🔧 Настройка системы..."
echo ""

# 1. Активация venv
source .venv/bin/activate

# 2. Установка зависимостей
echo "📦 Установка зависимостей..."
pip install -q psycopg2-binary fastapi uvicorn requests 2>&1 | grep -v "already satisfied" || true

# 3. Проверка/создание базы данных
echo "🗄️  Проверка PostgreSQL..."
if sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw cryptotrader; then
    echo "✅ База данных существует"
else
    echo "📝 Создание базы данных..."
    sudo -u postgres psql -c "CREATE DATABASE cryptotrader;" 2>&1 | grep -v "already exists" || true
fi

# 4. Применение схемы
if [ -f ../database/strategy_rating_schema.sql ]; then
    echo "📋 Применение схемы..."
    sudo -u postgres psql cryptotrader < ../database/strategy_rating_schema.sql 2>&1 | grep -v "already exists" || true
else
    echo "⚠️  Схема не найдена, создаю базовую..."
    sudo -u postgres psql cryptotrader <<EOF
CREATE TABLE IF NOT EXISTS strategy_ratings (
    id SERIAL PRIMARY KEY,
    strategy_name VARCHAR(255) NOT NULL,
    exchange VARCHAR(50) DEFAULT 'gateio',
    stake_currency VARCHAR(10) DEFAULT 'USDT',
    total_backtests INTEGER DEFAULT 0,
    median_total_trades INTEGER DEFAULT 0,
    median_win_rate DECIMAL(10,2) DEFAULT 0,
    median_total_profit_pct DECIMAL(10,2) DEFAULT 0,
    ninja_score DECIMAL(10,2) DEFAULT 0,
    leverage INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE,
    is_stalled BOOLEAN DEFAULT FALSE,
    has_lookahead_bias BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(strategy_name, exchange, stake_currency)
);

CREATE TABLE IF NOT EXISTS backtest_results (
    id SERIAL PRIMARY KEY,
    strategy_name VARCHAR(255) NOT NULL,
    pair VARCHAR(50),
    total_profit_pct DECIMAL(10,2),
    total_trades INTEGER,
    win_rate DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT NOW()
);
EOF
fi

# 5. Проверка подключения
echo "🔍 Проверка подключения..."
python3 -c "
import psycopg2
import os
DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/cryptotrader')
try:
    conn = psycopg2.connect(DATABASE_URL)
    print('✅ PostgreSQL подключение работает')
    conn.close()
except Exception as e:
    print(f'❌ Ошибка: {e}')
    exit(1)
" || exit 1

# 6. Остановка старого сервера
echo "🛑 Остановка старого сервера..."
lsof -ti:8889 | xargs kill -9 2>/dev/null || true
sleep 1

# 7. Запуск сервера в фоне
echo "🚀 Запуск API сервера..."
nohup python3 rating_api_server.py > api_server.log 2>&1 &
SERVER_PID=$!
echo "   PID: $SERVER_PID"
sleep 3

# 8. Тестирование endpoints
echo "🧪 Тестирование API..."
python3 test_api_endpoints.py

# 9. Проверка статуса
if curl -s http://localhost:8889/api/stats > /dev/null; then
    echo ""
    echo "✅ Все работает!"
    echo "🌐 API доступен: http://localhost:8889"
    echo "📊 Логи: tail -f api_server.log"
else
    echo ""
    echo "❌ Сервер не отвечает"
    echo "📋 Логи: cat api_server.log"
    exit 1
fi

