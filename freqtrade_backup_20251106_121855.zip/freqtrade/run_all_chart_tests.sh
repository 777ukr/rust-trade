#!/bin/bash
# Полное тестирование системы графика

echo "=========================================="
echo "🧪 ПОЛНОЕ ТЕСТИРОВАНИЕ ГРАФИКА"
echo "=========================================="
echo ""

cd /home/crypto/sites/cryptotrader.com/freqtrade

# 1. Проверка API сервера
echo "1️⃣  Проверка API сервера..."
if curl -s http://localhost:8889/api/strategies > /dev/null; then
    echo "   ✅ API сервер доступен"
else
    echo "   ❌ API сервер недоступен. Запустите: python3 rating_api_server.py"
    exit 1
fi

# 2. Тест API endpoint
echo ""
echo "2️⃣  Тест API endpoint chart-data..."
python3 test_chart_api.py

# 3. Интеграционный тест
echo ""
echo "3️⃣  Интеграционный тест..."
python3 test_chart_integration.py

# 4. Проверка синтаксиса Python
echo ""
echo "4️⃣  Проверка синтаксиса..."
python3 -m py_compile rating_api_server.py && echo "   ✅ rating_api_server.py - OK" || echo "   ❌ Ошибки синтаксиса"
python3 -m py_compile test_chart_api.py && echo "   ✅ test_chart_api.py - OK" || echo "   ❌ Ошибки синтаксиса"

# 5. Проверка HTML
echo ""
echo "5️⃣  Проверка HTML..."
if grep -q "loadChart" user_data/web/rating_ui.html; then
    echo "   ✅ Функция loadChart найдена"
else
    echo "   ❌ Функция loadChart не найдена"
fi

if grep -q "plotly" user_data/web/rating_ui.html -i; then
    echo "   ✅ Plotly.js подключен"
else
    echo "   ❌ Plotly.js не подключен"
fi

echo ""
echo "=========================================="
echo "✅ ТЕСТИРОВАНИЕ ЗАВЕРШЕНО"
echo "=========================================="




