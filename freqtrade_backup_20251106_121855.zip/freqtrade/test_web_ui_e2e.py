#!/usr/bin/env python3
"""
E2E тестирование веб-интерфейса системы рейтинга
Использует requests для проверки HTML и JavaScript функциональности
"""

import requests
import re
import json
from pathlib import Path
from typing import Dict, List, Optional, Any

API_URL = "http://localhost:8889"
UI_FILE = Path(__file__).parent / "user_data" / "web" / "rating_ui.html"

class WebUITester:
    """E2E тестирование веб-интерфейса"""
    
    def __init__(self):
        self.api_url = API_URL
        self.ui_file = UI_FILE
        
    def test_ui_file_exists(self) -> bool:
        """Проверка существования UI файла"""
        print(f"\n🔍 Проверка UI файла...")
        if self.ui_file.exists():
            size = self.ui_file.stat().st_size
            print(f"✅ UI файл найден: {self.ui_file} ({size} bytes)")
            return True
        else:
            print(f"❌ UI файл не найден: {self.ui_file}")
            return False
    
    def test_ui_content(self) -> Dict[str, bool]:
        """Проверка содержимого UI"""
        print(f"\n📄 Проверка содержимого UI...")
        
        if not self.ui_file.exists():
            return {}
        
        content = self.ui_file.read_text(encoding='utf-8')
        
        checks = {
            "Theme toggle": "theme-toggle" in content,
            "Tabs navigation": "tab-btn" in content,
            "Rankings table": "rankings-table" in content,
            "Filters panel": "filters-panel" in content,
            "Backtest modal": "backtest-modal" in content,
            "Strategy details modal": "strategy-details-modal" in content,
            "Stats dashboard": "stats-grid" in content,
            "API URL": f"const API_URL = '{self.api_url}'" in content or f'API_URL = "{self.api_url}"' in content,
            "Load rankings function": "loadRankings" in content,
            "Load stats function": "loadStats" in content,
            "Show strategy details": "showStrategyDetails" in content,
            "Tab switching": "switchTab" in content,
            "Filter application": "applyFilters" in content,
            "Dark/Light theme": "toggleTheme" in content,
        }
        
        passed = 0
        for check, result in checks.items():
            if result:
                print(f"✅ {check}")
                passed += 1
            else:
                print(f"❌ {check}")
        
        print(f"\n📊 Результат: {passed}/{len(checks)} проверок")
        return checks
    
    def test_ui_api_integration(self) -> bool:
        """Проверка интеграции UI с API"""
        print(f"\n🔗 Проверка интеграции UI с API...")
        
        if not self.ui_file.exists():
            return False
        
        content = self.ui_file.read_text(encoding='utf-8')
        
        # Проверяем что используются правильные endpoints
        api_endpoints = [
            "/api/strategies",
            "/api/stats",
            "/api/rankings",
            "/api/backtest/run",
            "/api/backtest/status",
            "/api/backtest/progress",
        ]
        
        found_endpoints = []
        for endpoint in api_endpoints:
            if endpoint in content:
                found_endpoints.append(endpoint)
        
        if len(found_endpoints) == len(api_endpoints):
            print(f"✅ Все API endpoints найдены в UI")
            return True
        else:
            missing = set(api_endpoints) - set(found_endpoints)
            print(f"⚠️  Отсутствуют endpoints: {', '.join(missing)}")
            return False
    
    def test_ui_features(self) -> Dict[str, bool]:
        """Проверка функций UI"""
        print(f"\n🎨 Проверка функций UI...")
        
        if not self.ui_file.exists():
            return {}
        
        content = self.ui_file.read_text(encoding='utf-8')
        
        features = {
            "Dark/Light theme toggle": "toggleTheme" in content and "localStorage" in content,
            "Tab navigation": "switchTab" in content and "tab-btn" in content,
            "Filters": "applyFilters" in content and "hide-negative" in content,
            "Strategy details modal": "showStrategyDetails" in content,
            "Monthly breakdown table": "monthly_breakdown" in content,
            "Indicators word cloud": "indicators" in content,
            "Auto-refresh": "setInterval" in content,
            "Notifications": "notification" in content.lower(),
            "Loading states": "loading" in content.lower(),
            "Sorting": "sortBy" in content,
        }
        
        passed = 0
        for feature, result in features.items():
            if result:
                print(f"✅ {feature}")
                passed += 1
            else:
                print(f"❌ {feature}")
        
        print(f"\n📊 Результат: {passed}/{len(features)} функций")
        return features
    
    def test_ui_served(self) -> bool:
        """Проверка что UI корректно отдается сервером"""
        print(f"\n🌐 Проверка отдачи UI сервером...")
        
        try:
            res = requests.get(f"{self.api_url}/", timeout=5)
            if res.status_code != 200:
                print(f"❌ Сервер вернул статус {res.status_code}")
                return False
            
            content = res.text
            
            # Проверяем что это HTML
            if "<!DOCTYPE html>" not in content and "<html" not in content:
                print(f"❌ Ответ не является HTML")
                return False
            
            # Проверяем наличие ключевых элементов
            checks = [
                "Strategy Rating System",
                "rankings-table",
                "theme-toggle",
                "API_URL"
            ]
            
            passed = sum(1 for check in checks if check in content)
            print(f"✅ UI корректно отдается сервером ({passed}/{len(checks)} проверок)")
            return passed == len(checks)
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            return False
    
    def run_all_tests(self) -> Dict[str, Any]:
        """Запустить все UI тесты"""
        print("=" * 70)
        print("🧪 E2E ТЕСТИРОВАНИЕ ВЕБ-ИНТЕРФЕЙСА")
        print("=" * 70)
        
        results = {
            "file_exists": self.test_ui_file_exists(),
            "content_checks": self.test_ui_content(),
            "api_integration": self.test_ui_api_integration(),
            "features": self.test_ui_features(),
            "served_correctly": self.test_ui_served(),
        }
        
        # Подсчет успешных тестов
        total_checks = (
            len(results["content_checks"]) +
            len(results["features"]) +
            3  # file_exists, api_integration, served_correctly
        )
        
        passed_checks = (
            sum(1 for v in results["content_checks"].values() if v) +
            sum(1 for v in results["features"].values() if v) +
            (1 if results["file_exists"] else 0) +
            (1 if results["api_integration"] else 0) +
            (1 if results["served_correctly"] else 0)
        )
        
        print("\n" + "=" * 70)
        print(f"📊 ИТОГИ: {passed_checks}/{total_checks} проверок прошли")
        
        if passed_checks == total_checks:
            print("✅ ВСЕ UI ТЕСТЫ ПРОШЛИ!")
        else:
            print("⚠️  Некоторые проверки не прошли")
        
        return results

if __name__ == "__main__":
    tester = WebUITester()
    results = tester.run_all_tests()

