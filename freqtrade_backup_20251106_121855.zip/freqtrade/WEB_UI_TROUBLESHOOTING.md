# 📊 Руководство по просмотру результатов в Freqtrade Web UI

## 🎯 Проблема: Пустая страница Backtesting

Если страница http://127.0.0.1:8081/backtesting пустая, выполните следующие шаги:

### ✅ Шаг 1: Проверка файлов

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
python3 fix_web_ui_display.py
```

Это проверит все файлы и создаст каталог результатов.

### ✅ Шаг 2: Перезапуск веб-сервера

Если API возвращает 503 или результаты не видны:

1. **Остановите текущий процесс freqtrade:**
   ```bash
   # Найдите процесс
   ps aux | grep freqtrade
   # Остановите (Ctrl+C или kill PID)
   ```

2. **Перезапустите:**
   ```bash
   cd /home/crypto/sites/cryptotrader.com/freqtrade
   source .venv/bin/activate
   freqtrade trade --config ../config/freqtrade_config.json --strategy TestStrategy
   ```

3. **Подождите 10-15 секунд** для инициализации

4. **Обновите страницу** http://127.0.0.1:8081/backtesting

### ✅ Шаг 3: Использование CLI (если веб-интерфейс не работает)

```bash
# Показать все результаты
freqtrade backtesting-show

# Показать конкретный результат
freqtrade backtesting-show --backtest-filename=backtest-result-2025-11-04_15-51-46.zip

# Показать рейтинг по парам
freqtrade backtesting-show --show-pair-list
```

### ✅ Шаг 4: Прямой доступ к результатам

Откройте HTML страницу с быстрым доступом:
```
file:///home/crypto/sites/cryptotrader.com/freqtrade/user_data/quick_access_results.html
```

## 📊 Текущие результаты

Всего бэктестов: 26

### Доступные стратегии:
- AdvancedIndicatorStrategy
- HookStrategy
- MShotStrategy
- MStrikeStrategy
- TestStrategy

## 🔗 Прямые ссылки

- **Backtesting:** http://127.0.0.1:8081/backtesting
- **Dashboard:** http://127.0.0.1:8081/dashboard
- **API History:** http://127.0.0.1:8081/api/v1/backtest/history

## 💡 Если ничего не помогает

1. Проверьте логи: `tail -f freqtrade.log`
2. Проверьте права доступа: `chmod 644 user_data/backtest_results/*`
3. Попробуйте другой браузер
4. Очистите кэш браузера (Ctrl+Shift+Delete)
