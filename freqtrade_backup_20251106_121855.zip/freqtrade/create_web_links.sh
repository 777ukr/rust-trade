#!/bin/bash
# Скрипт для создания прямых ссылок на результаты бэктестов

echo "🔗 Создание ссылок на результаты бэктестов"
echo ""

RESULTS_DIR="user_data/backtest_results"
WEB_UI_URL="http://127.0.0.1:8081"

echo "📊 Доступные результаты:"
echo ""

# Находим все метафайлы
for meta_file in "$RESULTS_DIR"/*.meta.json; do
    if [ -f "$meta_file" ]; then
        filename=$(basename "$meta_file" .meta.json)
        strategy=$(grep -o '"strategy": "[^"]*"' "$meta_file" | cut -d'"' -f4)
        timerange=$(grep -o '"timerange": "[^"]*"' "$meta_file" | cut -d'"' -f4 || echo "N/A")
        
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "📈 Стратегия: $strategy"
        echo "📅 Период: $timerange"
        echo "📁 Файл: $filename"
        echo ""
        echo "🌐 Прямые ссылки:"
        echo "   Веб-интерфейс: $WEB_UI_URL/backtesting"
        echo "   API: $WEB_UI_URL/api/v1/backtest/history/result?filename=$filename.zip&strategy=$strategy"
        echo ""
    fi
done

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "💡 Откройте в браузере:"
echo "   $WEB_UI_URL/backtesting"
echo ""
echo "📝 Логин: freqtrader"
echo "🔑 Пароль: см. config/freqtrade_config.json"

