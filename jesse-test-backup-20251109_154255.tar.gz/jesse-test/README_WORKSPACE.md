# Jesse Test Workspace - Быстрый старт

## 🚀 Открыть в отдельном окне

### Самый простой способ:

1. **File → Open Workspace from File...**
2. Выберите: `/home/crypto/sites/cryptotrader.com/jesse-test/jesse.code-workspace`
3. Нажмите **Open**

### Или через скрипт:

```bash
cd /home/crypto/sites/cryptotrader.com/jesse-test
./open_in_new_window.sh
```

### Или через терминал:

```bash
cursor /home/crypto/sites/cryptotrader.com/jesse-test/jesse.code-workspace --new-window
```

## ✅ Что происходит после открытия

1. Cursor загружает workspace `jesse.code-workspace`
2. Применяются правила из `.cursorrules`
3. Индексируются только файлы проекта Jesse
4. Настраивается правильный Python интерпретатор

## 🎯 Проверка

После открытия workspace проверьте:

- ✅ В заголовке: `jesse.code-workspace`
- ✅ В Explorer: только папка `jesse-test`
- ✅ Правила применены: используйте `@rules` в чате

## 🖥️ Запуск сервера

После открытия workspace запустите сервер:

```bash
./start_test_server_simple.sh
```

Сервер будет доступен на: **http://localhost:9001**

## 📝 Примечания

- Этот workspace изолирован от других проектов
- Использует отдельный порт (9001)
- Имеет свои правила и настройки
- Не конфликтует с Freqtrade или другими проектами

