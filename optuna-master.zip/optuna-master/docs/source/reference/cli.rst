.. module:: optuna.cli

optuna.cli
==========

The :mod:`~optuna.cli` module implements Optuna's command-line functionality.

For detail, please see the result of

.. code-block:: console

    $ optuna --help

.. seealso::
    The :ref:`cli` tutorial provides use-cases with examples.
