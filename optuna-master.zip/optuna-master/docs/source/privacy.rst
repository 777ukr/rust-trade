:orphan:

Privacy Policy
==============

Google Analytics
----------------

To collect information about how visitors use our website and to improve our services, we are using Google Analytics on this website. You can find out more about how Google Analytics works and about how information is collected on the Google Analytics terms of services and on Google's privacy policy.

- Google Analytics Terms of Service: http://www.google.com/analytics/terms/us.html
- Google Privacy Policy: https://policies.google.com/privacy?hl=en
- Google Analytics Opt-out Add-on: https://tools.google.com/dlpage/gaoptout?hl=en
