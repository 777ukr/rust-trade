.. _recipes:

Recipes
-------

Showcases the recipes that might help you using Optuna with comfort.
