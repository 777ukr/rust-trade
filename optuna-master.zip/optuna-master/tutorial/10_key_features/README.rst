.. _key_features:

Key Features
------------

Showcases Optuna's `Key Features <https://github.com/optuna/optuna/blob/master/README.md#key-features>`__.
