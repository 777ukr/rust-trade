import{a as r,B as t}from"./DClyChXX.js";const s={};function a(e,n){return t(e.$slots,"default")}const c=r(s,[["render",a]]);export{c as default};
