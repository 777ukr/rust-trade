#!/usr/bin/env python3
"""
Strategy Test Runner - Интерфейс для запуска тестов стратегий
Позволяет выбирать стратегии и запускать бэктесты через веб-интерфейс
"""

import json
import subprocess
import sys
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import time

FREQTRADE_DIR = Path(__file__).parent
CONFIG_PATH = FREQTRADE_DIR.parent / "config" / "freqtrade_config.json"
STRATEGIES_DIR = FREQTRADE_DIR / "user_data" / "strategies"
RESULTS_DIR = FREQTRADE_DIR / "user_data" / "backtest_results"
RATINGS_DIR = FREQTRADE_DIR / "user_data" / "ratings"
WEB_DIR = FREQTRADE_DIR / "user_data" / "web"

# Автоматическое обнаружение всех стратегий
def get_all_strategies():
    """Автоматически находит все стратегии в папке"""
    strategies = []
    for file in STRATEGIES_DIR.glob("*.py"):
        if file.name != "__init__.py" and not file.name.startswith("_"):
            strategies.append(file.stem)
    return sorted(strategies)

# Параметры бэктеста
END_DATE = datetime.now().strftime("%Y%m%d")
START_DATE = (datetime.now() - timedelta(days=30)).strftime("%Y%m%d")
TIMERANGE = f"{START_DATE}-{END_DATE}"
TIMEFRAME = "5m"
PAIR = "BTC/USDT"


class StrategyTestRunner:
    """Класс для запуска тестов стратегий"""
    
    def __init__(self):
        self.active_strategies = get_all_strategies()  # Автоматическое обнаружение
    
    def get_available_strategies(self) -> List[str]:
        """Получить список доступных стратегий"""
        strategies = []
        for file in STRATEGIES_DIR.glob("*.py"):
            if file.name != "__init__.py" and not file.name.startswith("_"):
                strategy_name = file.stem
                if strategy_name in self.active_strategies:
                    strategies.append(strategy_name)
        return strategies
    
    def run_backtest(self, strategy_name: str, pair: str = PAIR, 
                     timerange: str = TIMERANGE, timeframe: str = TIMEFRAME) -> Dict:
        """Запустить бэктест для стратегии"""
        print(f"\n{'='*70}")
        print(f"🧪 Тестирование: {strategy_name} на {pair}")
        print(f"{'='*70}")
        
        cmd = [
            "freqtrade", "backtesting",
            "--config", str(CONFIG_PATH),
            "--strategy", strategy_name,
            "--timerange", timerange,
            "--timeframe", timeframe,
            "--pairs", pair,
            "--export", "trades",
            "--breakdown", "month",
            "--cache", "none"
        ]
        
        print(f"📋 Команда: {' '.join(cmd)}")
        
        try:
            start_time = time.time()
            result = subprocess.run(
                cmd,
                cwd=str(FREQTRADE_DIR),
                capture_output=True,
                text=True,
                timeout=600
            )
            
            elapsed = time.time() - start_time
            
            if result.returncode != 0:
                return {
                    "success": False,
                    "strategy": strategy_name,
                    "error": result.stderr[:500] if result.stderr else "Unknown error",
                    "elapsed_seconds": elapsed
                }
            
            # Проверяем созданные файлы
            time.sleep(1)
            meta_files = sorted(
                RESULTS_DIR.glob("*.meta.json"),
                key=lambda x: x.stat().st_mtime,
                reverse=True
            )
            
            if meta_files:
                latest_meta = meta_files[0]
                return {
                    "success": True,
                    "strategy": strategy_name,
                    "pair": pair,
                    "meta_file": latest_meta.name,
                    "zip_file": latest_meta.name.replace(".meta.json", ".zip"),
                    "elapsed_seconds": elapsed,
                    "timestamp": datetime.now().isoformat()
                }
            else:
                return {
                    "success": True,
                    "strategy": strategy_name,
                    "pair": pair,
                    "note": "Backtest completed but no meta file found",
                    "elapsed_seconds": elapsed
                }
                
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "strategy": strategy_name,
                "error": "Timeout (бэктест занял более 10 минут)",
                "elapsed_seconds": 600
            }
        except Exception as e:
            return {
                "success": False,
                "strategy": strategy_name,
                "error": str(e),
                "elapsed_seconds": 0
            }
    
    def run_all_active_strategies(self) -> List[Dict]:
        """Запустить бэктесты для всех активных стратегий"""
        results = []
        strategies = self.get_available_strategies()
        
        print(f"🚀 Запуск тестов для {len(strategies)} стратегий...")
        
        for strategy in strategies:
            result = self.run_backtest(strategy)
            results.append(result)
            time.sleep(2)  # Небольшая пауза между тестами
        
        return results
    
    def create_test_interface_html(self, results: Optional[List[Dict]] = None):
        """Создать веб-интерфейс для запуска тестов"""
        WEB_DIR.mkdir(parents=True, exist_ok=True)
        
        strategies = self.get_available_strategies()
        
        html = f"""<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Strategy Test Runner</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        .header {{
            background: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }}
        .card {{
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }}
        .btn {{
            display: inline-block;
            padding: 12px 24px;
            background: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            margin: 5px;
        }}
        .btn:hover {{ background: #45a049; }}
        .btn-secondary {{
            background: #2196F3;
        }}
        .btn-secondary:hover {{ background: #0b7dda; }}
        .btn-danger {{
            background: #f44336;
        }}
        .btn-danger:hover {{ background: #da190b; }}
        .strategy-list {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }}
        .strategy-item {{
            background: #f5f5f5;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid #4CAF50;
        }}
        .strategy-item h3 {{
            margin-bottom: 10px;
            color: #333;
        }}
        .results {{
            margin-top: 20px;
        }}
        .result-item {{
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            background: #f9f9f9;
        }}
        .result-success {{
            border-left: 4px solid #4CAF50;
        }}
        .result-error {{
            border-left: 4px solid #f44336;
        }}
        .loading {{
            display: none;
            text-align: center;
            padding: 20px;
        }}
        .loading.active {{
            display: block;
        }}
        .spinner {{
            border: 4px solid #f3f3f3;
            border-top: 4px solid #4CAF50;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }}
        @keyframes spin {{
            0% {{ transform: rotate(0deg); }}
            100% {{ transform: rotate(360deg); }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🧪 Strategy Test Runner</h1>
            <p style="color: #666; margin-top: 10px;">
                Запуск бэктестов для активных стратегий
            </p>
        </div>

        <div class="card">
            <h2>📋 Активные стратегии ({len(strategies)})</h2>
            <div class="strategy-list">
"""
        
        for strategy in strategies:
            html += f"""
                <div class="strategy-item">
                    <h3>{strategy}</h3>
                    <button class="btn" onclick="runTest('{strategy}')">Запустить тест</button>
                </div>
"""
        
        html += """
            </div>
            
            <div style="margin-top: 20px;">
                <button class="btn btn-secondary" onclick="runAllTests()">Запустить все тесты</button>
                <button class="btn btn-secondary" onclick="updateRankings()">Обновить рейтинг</button>
                <a href="strategy_rankings.html" class="btn btn-secondary">Просмотр рейтинга</a>
            </div>
        </div>

        <div class="card">
            <h2>📊 Результаты тестов</h2>
            <div class="loading" id="loading">
                <div class="spinner"></div>
                <p style="margin-top: 10px;">Запуск тестов...</p>
            </div>
            <div class="results" id="results">
                <p style="color: #666;">Результаты появятся здесь после запуска тестов</p>
            </div>
        </div>
    </div>

    <script>
        function runTest(strategy) {
            const loading = document.getElementById('loading');
            const results = document.getElementById('results');
            
            loading.classList.add('active');
            results.innerHTML = '<p>Запуск теста для ' + strategy + '...</p>';
            
            // В реальной реализации здесь будет AJAX запрос к серверу
            // Для демо показываем сообщение
            setTimeout(() => {
                loading.classList.remove('active');
                results.innerHTML = `
                    <div class="result-item result-success">
                        <h3>✅ ${strategy}</h3>
                        <p>Тест запущен. Запустите в терминале:</p>
                        <code>python3 strategy_test_runner.py --strategy ${strategy}</code>
                    </div>
                `;
            }, 1000);
        }
        
        function runAllTests() {
            const strategies = """ + json.dumps(strategies) + """;
            const loading = document.getElementById('loading');
            const results = document.getElementById('results');
            
            loading.classList.add('active');
            results.innerHTML = '<p>Запуск всех тестов...</p>';
            
            setTimeout(() => {
                loading.classList.remove('active');
                results.innerHTML = `
                    <div class="result-item result-success">
                        <h3>✅ Все тесты запущены</h3>
                        <p>Запустите в терминале:</p>
                        <code>python3 strategy_test_runner.py --all</code>
                    </div>
                `;
            }, 1000);
        }
        
        function updateRankings() {
            window.location.href = 'strategy_rankings.html';
        }
    </script>
</body>
</html>
"""
        
        html_file = WEB_DIR / "test_runner.html"
        html_file.write_text(html, encoding='utf-8')
        
        print(f"✅ Веб-интерфейс создан: {html_file}")
        return html_file


def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Strategy Test Runner')
    parser.add_argument('--strategy', type=str, help='Strategy name to test')
    parser.add_argument('--all', action='store_true', help='Test all active strategies')
    parser.add_argument('--create-interface', action='store_true', help='Create web interface')
    
    args = parser.parse_args()
    
    runner = StrategyTestRunner()
    
    if args.create_interface:
        runner.create_test_interface_html()
        print("✅ Веб-интерфейс создан!")
        return
    
    if args.all:
        results = runner.run_all_active_strategies()
        print("\n" + "="*70)
        print("📊 Результаты тестов:")
        print("="*70)
        for result in results:
            if result.get("success"):
                print(f"✅ {result['strategy']}: {result.get('meta_file', 'OK')}")
            else:
                print(f"❌ {result['strategy']}: {result.get('error', 'Failed')}")
    elif args.strategy:
        result = runner.run_backtest(args.strategy)
        if result.get("success"):
            print(f"\n✅ Успешно: {result}")
        else:
            print(f"\n❌ Ошибка: {result}")
    else:
        # Создать интерфейс по умолчанию
        runner.create_test_interface_html()
        print("\n💡 Использование:")
        print("   python3 strategy_test_runner.py --strategy MShotStrategy")
        print("   python3 strategy_test_runner.py --all")
        print("   python3 strategy_test_runner.py --create-interface")


if __name__ == "__main__":
    main()

