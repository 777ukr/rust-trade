# 🚀 Быстрый старт: Тестирование стратегий

## ✅ Что готово

1. **MShotStrategy** - адаптация Rust стратегии `mshot.rs`
2. **AdvancedIndicatorStrategy** - стратегия с множеством индикаторов
3. **Скрипт автоматического тестирования** - `test_and_rank_strategies.py`
4. **Система рейтинга** - автоматическое вычисление метрик

## 🎯 Быстрый тест (5 минут)

### Вариант 1: Быстрый тест одной стратегии

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate
./quick_test.sh
```

### Вариант 2: Тест с автоматическим рейтингом

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate
python test_and_rank_strategies.py
```

## 📊 Что вы получите

После тестирования вы увидите:

```
🏆 РЕЙТИНГ СТРАТЕГИЙ
================================================================================
№    Стратегия                  Пара         Рейтинг  ⭐      PNL%     Сделок
--------------------------------------------------------------------------------
1    MShotStrategy              BTC/USDT     7.50     ⭐⭐⭐   12.5     150
2    AdvancedIndicatorStrategy   BTC/USDT     6.80     ⭐⭐⭐   8.2      120
```

## 📁 Где найти результаты

- **JSON с рейтингами:** `user_data/backtest_results/strategy_rankings_*.json`
- **CSV с сделками:** `user_data/backtest_results/{strategy}_{pair}_trades.csv`

## 🔧 Настройка периода тестирования

Откройте `test_and_rank_strategies.py` и измените:

```python
TIMERANGE = "20241101-20241201"  # Измените на нужный период
```

## 💡 Следующие шаги

1. **Запустите быстрый тест** - `./quick_test.sh`
2. **Проверьте результаты** - откройте JSON файл с рейтингами
3. **Оптимизируйте параметры** - используйте Hyperopt для лучших результатов
4. **Сравните с Rust версией** - проверьте метрики в Rust бэктестере

## 📚 Подробная документация

См. `STRATEGY_TESTING.md` для полной документации.

