#!/usr/bin/env python3
"""
Тесты для API графика
Проверяет корректность работы endpoint /api/strategies/{name}/chart-data
"""

import requests
import json
from pathlib import Path

API_URL = "http://localhost:8889"

def test_chart_api_endpoint():
    """Тест endpoint для получения данных графика"""
    print("🧪 Тестирование API графика...")
    
    # Получаем список стратегий
    try:
        res = requests.get(f"{API_URL}/api/strategies", timeout=5)
        if res.status_code != 200:
            print(f"❌ Ошибка получения стратегий: {res.status_code}")
            return False
        
        strategies = res.json().get("strategies", [])
        if not strategies:
            print("⚠️  Нет стратегий для тестирования")
            return True
        
        # Тестируем первую стратегию
        strategy_name = strategies[0]["name"]
        print(f"📊 Тестируем стратегию: {strategy_name}")
        
        # Тест 1: Получение данных графика
        try:
            res = requests.get(
                f"{API_URL}/api/strategies/{strategy_name}/chart-data",
                params={"pair": "BTC/USDT", "timeframe": "5m", "limit": 100},
                timeout=10
            )
            
            if res.status_code != 200:
                print(f"⚠️  Статус {res.status_code}, но это может быть нормально если нет данных")
                print(f"   Ответ: {res.text[:200]}")
                # Проверяем структуру ответа даже при ошибке
                try:
                    data = res.json()
                    if 'has_data' in data:
                        print(f"   ✅ Структура ответа корректна (has_data: {data.get('has_data')})")
                        return True
                except:
                    pass
                return False
        except Exception as e:
            print(f"❌ Ошибка запроса: {e}")
            return False
        
        data = res.json()
        
        # Проверяем структуру ответа
        required_fields = ["strategy_name", "pair", "timeframe", "ohlcv", 
                          "entry_points", "exit_points", "stop_loss_lines", 
                          "take_profit_lines", "total_trades"]
        
        for field in required_fields:
            if field not in data:
                print(f"❌ Отсутствует поле: {field}")
                return False
        
        print(f"✅ Структура данных корректна")
        print(f"   OHLCV свечей: {len(data['ohlcv'])}")
        print(f"   Точки входа: {len(data['entry_points'])}")
        print(f"   Точки выхода: {len(data['exit_points'])}")
        print(f"   Линии стоп-лосса: {len(data['stop_loss_lines'])}")
        
        # Тест 2: Проверка формата данных
        if data['ohlcv']:
            first_candle = data['ohlcv'][0]
            required_candle_fields = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
            for field in required_candle_fields:
                if field not in first_candle:
                    print(f"❌ Отсутствует поле в свече: {field}")
                    return False
            print("✅ Формат OHLCV корректен")
        
        if data['entry_points']:
            first_entry = data['entry_points'][0]
            required_entry_fields = ['x', 'y']
            for field in required_entry_fields:
                if field not in first_entry:
                    print(f"❌ Отсутствует поле в точке входа: {field}")
                    return False
            print("✅ Формат точек входа корректен")
        
        # Тест 3: Проверка на несуществующую стратегию
        res = requests.get(
            f"{API_URL}/api/strategies/NonExistentStrategy123/chart-data",
            timeout=5
        )
        if res.status_code != 200:
            print(f"❌ Ошибка при несуществующей стратегии: {res.status_code}")
            return False
        
        data = res.json()
        if data.get('has_data', True):
            print("⚠️  Несуществующая стратегия вернула данные (ожидалось пусто)")
        else:
            print("✅ Несуществующая стратегия корректно обработана")
        
        print("✅ Все тесты пройдены!")
        return True
        
    except requests.exceptions.ConnectionError:
        print("❌ Не удалось подключиться к API. Убедитесь, что сервер запущен на http://localhost:8889")
        return False
    except Exception as e:
        print(f"❌ Ошибка тестирования: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_chart_data_format():
    """Тест формата данных для графика"""
    print("\n🧪 Тестирование формата данных...")
    
    # Проверяем, что timestamp можно конвертировать в Date
    test_data = {
        "ohlcv": [
            {"timestamp": 1640995200, "open": 50000, "high": 51000, "low": 49000, "close": 50500, "volume": 1000}
        ],
        "entry_points": [
            {"x": 1640995200, "y": 50000, "trade_id": "1", "profit_pct": 2.5}
        ],
        "exit_points": [
            {"x": 1640998800, "y": 50500, "trade_id": "1", "profit_pct": 2.5, "profit_abs": 500}
        ]
    }
    
    # Проверяем типы
    for candle in test_data['ohlcv']:
        assert isinstance(candle['timestamp'], (int, float)), "Timestamp должен быть числом"
        assert isinstance(candle['open'], (int, float)), "Open должен быть числом"
    
    for entry in test_data['entry_points']:
        assert isinstance(entry['x'], (int, float)), "Entry x должен быть числом"
        assert isinstance(entry['y'], (int, float)), "Entry y должен быть числом"
    
    print("✅ Формат данных валиден")
    return True

if __name__ == "__main__":
    print("=" * 60)
    print("ТЕСТИРОВАНИЕ API ГРАФИКА")
    print("=" * 60)
    
    success = True
    success &= test_chart_api_endpoint()
    success &= test_chart_data_format()
    
    print("\n" + "=" * 60)
    if success:
        print("✅ ВСЕ ТЕСТЫ ПРОЙДЕНЫ")
    else:
        print("❌ НЕКОТОРЫЕ ТЕСТЫ ПРОВАЛЕНЫ")
    print("=" * 60)

