# 📥 Загрузка данных для Gate.io

## ⚠️ Важное ограничение

**Gate.io ограничивает загрузку исторических данных до 10000 точек.**

Для таймфрейма 5m это примерно:
- **30 дней** = ~8640 свечей ✅
- **34 дня** = ~9792 свечи ✅ (максимум)
- **35+ дней** = ❌ Ошибка "Candlestick too long ago"

## 📊 Рекомендуемые периоды

| Таймфрейм | Максимум дней | Свечей |
|-----------|---------------|--------|
| 1m        | ~6 дней       | ~8640  |
| 5m        | ~34 дня      | ~9792  |
| 15m       | ~104 дня     | ~9984  |
| 1h        | ~416 дней    | ~9984  |
| 1d        | ~27 лет      | ~10000 |

## 🚀 Быстрая загрузка данных

### Последние 30 дней (рекомендуется)

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
source .venv/bin/activate

freqtrade download-data \
    --exchange gateio \
    --pairs BTC/USDT \
    --timeframes 5m \
    --days 30 \
    --config ../config/freqtrade_config.json
```

### Максимальный период для 5m (34 дня)

```bash
freqtrade download-data \
    --exchange gateio \
    --pairs BTC/USDT ETH/USDT SOL/USDT \
    --timeframes 5m \
    --days 34 \
    --config ../config/freqtrade_config.json
```

### Для других таймфреймов (15m, 4h, 6h)

```bash
# 15m - до 104 дней
freqtrade download-data \
    --exchange gateio \
    --pairs BTC/USDT \
    --timeframes 15m \
    --days 100 \
    --config ../config/freqtrade_config.json

# 4h - до 416 дней
freqtrade download-data \
    --exchange gateio \
    --pairs BTC/USDT \
    --timeframes 4h \
    --days 400 \
    --config ../config/freqtrade_config.json
```

## 📁 Где хранятся данные

Данные сохраняются в:
```
freqtrade/user_data/data/gateio/
  └── BTC_USDT-5m.json
```

## 🔍 Проверка загруженных данных

```bash
# Проверить количество свечей
ls -lh user_data/data/gateio/*.json

# Или через freqtrade
freqtrade list-data --config ../config/freqtrade_config.json
```

## 💡 Альтернативы для больших периодов

Если нужны данные за год или больше:

1. **Используйте другой таймфрейм** (1h, 4h, 1d)
2. **Используйте другую биржу** (Binance, Coinbase) для исторических данных
3. **Комбинируйте данные** - загрузите по частям и объедините

## 🔄 Автоматическая загрузка

Скрипт `quick_test.sh` автоматически загружает данные если их нет:

```bash
./quick_test.sh
```


