#!/usr/bin/env python3
"""
Comprehensive Test Suite - Полное тестирование всей системы
Проверяет все компоненты на 100% работоспособность
"""

import sys
import os
import json
import requests
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import time
import traceback

# Добавляем путь к модулям
FREQTRADE_DIR = Path(__file__).parent
sys.path.insert(0, str(FREQTRADE_DIR))

API_URL = "http://localhost:8889"

class TestResult:
    """Результат теста"""
    def __init__(self, name: str, success: bool, message: str = "", duration: float = 0):
        self.name = name
        self.success = success
        self.message = message
        self.duration = duration
        self.timestamp = datetime.now().isoformat()

class ComprehensiveTestSuite:
    """Комплексная система тестирования"""
    
    def __init__(self):
        self.results: List[TestResult] = []
        self.start_time = time.time()
        
    def run_test(self, test_func, test_name: str):
        """Запустить тест и записать результат"""
        start = time.time()
        try:
            result = test_func()
            duration = time.time() - start
            if result:
                self.results.append(TestResult(test_name, True, "✅ Passed", duration))
                return True
            else:
                self.results.append(TestResult(test_name, False, "❌ Failed", duration))
                return False
        except Exception as e:
            duration = time.time() - start
            self.results.append(TestResult(test_name, False, f"❌ Error: {str(e)}", duration))
            traceback.print_exc()
            return False
    
    def test_api_server_availability(self) -> bool:
        """Тест 1: Доступность API сервера"""
        try:
            response = requests.get(f"{API_URL}/api/strategies", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def test_api_endpoints(self) -> bool:
        """Тест 2: Все основные API endpoints"""
        endpoints = [
            "/api/strategies",
            "/api/rankings",
            "/api/stats",
            "/api/backtest/status",
        ]
        
        for endpoint in endpoints:
            try:
                response = requests.get(f"{API_URL}{endpoint}", timeout=5)
                if response.status_code not in [200, 404]:
                    print(f"  ⚠️  {endpoint}: {response.status_code}")
                    return False
            except Exception as e:
                print(f"  ❌ {endpoint}: {e}")
                return False
        return True
    
    def test_strategy_discovery(self) -> bool:
        """Тест 3: Автоматическое обнаружение стратегий"""
        try:
            from strategy_rating_system_standalone import get_all_strategies
            strategies = get_all_strategies()
            return len(strategies) > 0
        except Exception as e:
            print(f"  Error: {e}")
            return False
    
    def test_backtest_results_parsing(self) -> bool:
        """Тест 4: Парсинг результатов бэктестов"""
        try:
            results_dir = FREQTRADE_DIR / "user_data" / "backtest_results"
            zip_files = list(results_dir.glob("*.zip"))
            if not zip_files:
                print("  ⚠️  Нет ZIP файлов для тестирования")
                return True  # Не критично
            
            # Пробуем распарсить первый файл
            import zipfile
            with zipfile.ZipFile(zip_files[0], 'r') as zip_ref:
                json_files = [f for f in zip_ref.namelist() if f.endswith('.json')]
                return len(json_files) > 0
        except Exception as e:
            print(f"  Error: {e}")
            return False
    
    def test_chart_api_endpoint(self) -> bool:
        """Тест 5: API endpoint для графиков"""
        try:
            # Получаем список стратегий
            response = requests.get(f"{API_URL}/api/strategies", timeout=5)
            if response.status_code != 200:
                return False
            
            strategies = response.json().get("strategies", [])
            if not strategies:
                return True  # Нет стратегий - не критично
            
            # Тестируем chart-data endpoint
            strategy_name = strategies[0]["name"]
            response = requests.get(
                f"{API_URL}/api/strategies/{strategy_name}/chart-data",
                params={"pair": "BTC/USDT", "timeframe": "5m"},
                timeout=10
            )
            return response.status_code == 200
        except:
            return False
    
    def test_data_validation(self) -> bool:
        """Тест 6: Валидация данных"""
        try:
            # Проверяем структуру ответов API
            response = requests.get(f"{API_URL}/api/strategies", timeout=5)
            if response.status_code != 200:
                return False
            
            data = response.json()
            required_fields = ["strategies"]
            for field in required_fields:
                if field not in data:
                    return False
            return True
        except:
            return False
    
    def test_error_handling(self) -> bool:
        """Тест 7: Обработка ошибок"""
        try:
            # Тестируем несуществующие endpoints
            response = requests.get(f"{API_URL}/api/nonexistent", timeout=5)
            # Должен вернуть 404 или 422, не 500
            return response.status_code in [404, 422, 405]
        except:
            return False
    
    def test_file_structure(self) -> bool:
        """Тест 8: Структура файлов"""
        required_dirs = [
            "user_data/strategies",
            "user_data/backtest_results",
            "user_data/ratings",
            "user_data/web",
        ]
        
        for dir_path in required_dirs:
            full_path = FREQTRADE_DIR / dir_path
            if not full_path.exists():
                print(f"  ❌ Отсутствует: {dir_path}")
                return False
        return True
    
    def test_imports(self) -> bool:
        """Тест 9: Импорты всех модулей"""
        # Обязательные модули
        required_modules = [
            "strategy_rating_system_standalone",
        ]
        
        # Опциональные модули (если не доступны - не критично)
        optional_modules = [
            "rating_api_server",  # Может требовать psycopg2, но есть fallback
            "gateio_data_parser",
            "gateio_coin_parser",
            "live_simulation_engine",
            "profitability_forecaster",
            "premium_data_provider",
        ]
        
        # Проверяем обязательные модули
        for module_name in required_modules:
            try:
                __import__(module_name)
            except ImportError as e:
                print(f"  ❌ Не удалось импортировать обязательный модуль {module_name}: {e}")
                return False
        
        # Проверяем опциональные модули (предупреждения, но не ошибки)
        failed_optional = []
        for module_name in optional_modules:
            try:
                __import__(module_name)
            except ImportError as e:
                failed_optional.append(f"{module_name} ({str(e)[:50]})")
        
        if failed_optional:
            print(f"  ⚠️  Опциональные модули недоступны: {', '.join(failed_optional)}")
            print(f"     (Это нормально, если есть fallback механизмы)")
        
        return True
    
    def test_strategy_files(self) -> bool:
        """Тест 10: Проверка файлов стратегий"""
        strategies_dir = FREQTRADE_DIR / "user_data" / "strategies"
        strategy_files = list(strategies_dir.glob("*.py"))
        
        if not strategy_files:
            print("  ⚠️  Нет файлов стратегий")
            return True  # Не критично
        
        # Проверяем, что файлы не пустые
        for strategy_file in strategy_files[:5]:  # Проверяем первые 5
            if strategy_file.stat().st_size == 0:
                print(f"  ❌ Пустой файл: {strategy_file.name}")
                return False
        return True
    
    def test_configuration(self) -> bool:
        """Тест 11: Конфигурация"""
        config_file = FREQTRADE_DIR.parent / "config" / "freqtrade_config.json"
        if not config_file.exists():
            print("  ⚠️  Config файл не найден (не критично)")
            return True  # Не критично
        
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
                
                # Обязательные поля
                required_fields = ["exchange"]
                for field in required_fields:
                    if field not in config:
                        print(f"  ❌ Отсутствует обязательное поле: {field}")
                        return False
                
                # Опциональные поля (предупреждения)
                optional_fields = ["pair_whitelist"]
                missing_optional = []
                for field in optional_fields:
                    if field not in config:
                        missing_optional.append(field)
                
                if missing_optional:
                    print(f"  ⚠️  Опциональные поля отсутствуют: {', '.join(missing_optional)}")
                    print(f"     (Это нормально, пары можно передавать через --pairs)")
            
            return True
        except Exception as e:
            print(f"  ⚠️  Ошибка чтения конфига: {e} (не критично)")
            return True  # Не критично, если конфиг не читается
    
    def test_ui_files(self) -> bool:
        """Тест 12: UI файлы"""
        ui_file = FREQTRADE_DIR / "user_data" / "web" / "rating_ui.html"
        if not ui_file.exists():
            print("  ❌ UI файл не найден")
            return False
        
        # Проверяем, что файл содержит основные элементы
        with open(ui_file, 'r', encoding='utf-8') as f:
            content = f.read()
            required_elements = [
                "loadRankings",
                "loadStats",
                "startBacktest",
                "showStrategyDetails",
            ]
            for element in required_elements:
                if element not in content:
                    print(f"  ❌ Отсутствует элемент: {element}")
                    return False
        return True
    
    def run_all_tests(self):
        """Запустить все тесты"""
        print("=" * 70)
        print("🧪 COMPREHENSIVE TEST SUITE")
        print("=" * 70)
        print()
        
        tests = [
            ("API Server Availability", self.test_api_server_availability),
            ("API Endpoints", self.test_api_endpoints),
            ("Strategy Discovery", self.test_strategy_discovery),
            ("Backtest Results Parsing", self.test_backtest_results_parsing),
            ("Chart API Endpoint", self.test_chart_api_endpoint),
            ("Data Validation", self.test_data_validation),
            ("Error Handling", self.test_error_handling),
            ("File Structure", self.test_file_structure),
            ("Module Imports", self.test_imports),
            ("Strategy Files", self.test_strategy_files),
            ("Configuration", self.test_configuration),
            ("UI Files", self.test_ui_files),
        ]
        
        print("Запуск тестов...")
        print()
        
        for test_name, test_func in tests:
            print(f"🔍 {test_name}...", end=" ", flush=True)
            success = self.run_test(test_func, test_name)
            if success:
                print("✅")
            else:
                print("❌")
        
        # Выводим итоги
        print()
        print("=" * 70)
        print("📊 РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ")
        print("=" * 70)
        
        total = len(self.results)
        passed = sum(1 for r in self.results if r.success)
        failed = total - passed
        
        print(f"\nВсего тестов: {total}")
        print(f"✅ Успешно: {passed}")
        print(f"❌ Провалено: {failed}")
        print(f"⏱️  Время выполнения: {time.time() - self.start_time:.2f} сек")
        
        if failed > 0:
            print("\n❌ Проваленные тесты:")
            for result in self.results:
                if not result.success:
                    print(f"  - {result.name}: {result.message}")
        
        print()
        print("=" * 70)
        if failed == 0:
            print("✅ ВСЕ ТЕСТЫ ПРОЙДЕНЫ!")
        else:
            print(f"⚠️  {failed} ТЕСТОВ ПРОВАЛЕНО")
        print("=" * 70)
        
        return failed == 0

if __name__ == "__main__":
    suite = ComprehensiveTestSuite()
    success = suite.run_all_tests()
    sys.exit(0 if success else 1)
