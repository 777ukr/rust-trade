#!/bin/bash
# Comprehensive code quality check and testing script

echo "🔍 Проверка качества кода и тестирование..."
echo ""

cd /home/crypto/sites/cryptotrader.com/freqtrade

# 1. Синтаксическая проверка Python
echo "1️⃣  Синтаксическая проверка Python..."
python3 -m py_compile rating_api_server.py live_simulation_engine.py user_data/strategies/base_strategy_v2.py 2>&1
if [ $? -eq 0 ]; then
    echo "   ✅ Синтаксис Python OK"
else
    echo "   ❌ Ошибки синтаксиса"
    exit 1
fi
echo ""

# 2. Проверка импортов
echo "2️⃣  Проверка импортов..."
python3 -c "
import sys
sys.path.insert(0, '.')
try:
    import rating_api_server
    print('   ✅ rating_api_server импортирован')
except Exception as e:
    print(f'   ⚠️  rating_api_server: {e}')

try:
    from live_simulation_engine import LiveSimulationEngine, StrategyAutoSwitcher
    print('   ✅ live_simulation_engine импортирован')
except Exception as e:
    print(f'   ⚠️  live_simulation_engine: {e}')

try:
    from user_data.strategies.base_strategy_v2 import BaseStrategyV2
    print('   ✅ base_strategy_v2 импортирован')
except Exception as e:
    print(f'   ⚠️  base_strategy_v2: {e}')
" 2>&1
echo ""

# 3. Проверка API endpoints
echo "3️⃣  Проверка API endpoints..."
if curl -s http://localhost:8889/api/stats > /dev/null 2>&1; then
    echo "   ✅ API сервер доступен"
    curl -s http://localhost:8889/api/stats | python3 -m json.tool > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "   ✅ /api/stats возвращает валидный JSON"
    fi
    
    curl -s http://localhost:8889/api/strategies | python3 -m json.tool > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "   ✅ /api/strategies возвращает валидный JSON"
    fi
    
    curl -s "http://localhost:8889/api/strategies/AdvancedIndicatorStrategy/chart-data?pair=BTC/USDT&timeframe=5m" | python3 -m json.tool > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "   ✅ /api/strategies/{name}/chart-data возвращает валидный JSON"
    fi
else
    echo "   ⚠️  API сервер не доступен (запустите: python3 rating_api_server.py)"
fi
echo ""

# 4. Проверка использования logger вместо print
echo "4️⃣  Проверка использования logger..."
PRINT_COUNT=$(grep -c "print(" rating_api_server.py 2>/dev/null | grep -v "^$" | head -1 || echo "0")
if [ -z "$PRINT_COUNT" ] || [ "$PRINT_COUNT" = "0" ]; then
    echo "   ✅ Нет print() statements в rating_api_server.py (используется logger)"
else
    echo "   ⚠️  Найдено $PRINT_COUNT print() statements в rating_api_server.py (рекомендуется использовать logger)"
fi

PRINT_COUNT_LIVE=$(grep -c "print(" live_simulation_engine.py 2>/dev/null | grep -v "^$" | head -1 || echo "0")
if [ -z "$PRINT_COUNT_LIVE" ] || [ "$PRINT_COUNT_LIVE" = "0" ]; then
    echo "   ✅ Нет print() statements в live_simulation_engine.py (используется logger)"
else
    echo "   ⚠️  Найдено $PRINT_COUNT_LIVE print() statements в live_simulation_engine.py (рекомендуется использовать logger)"
fi
echo ""

# 5. Проверка структуры файлов
echo "5️⃣  Проверка структуры файлов..."
REQUIRED_FILES=(
    "rating_api_server.py"
    "live_simulation_engine.py"
    "user_data/strategies/base_strategy_v2.py"
    "user_data/web/rating_ui.html"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "   ✅ $file существует"
    else
        echo "   ❌ $file не найден"
    fi
done
echo ""

# 6. Запуск тестов (если pytest установлен)
echo "6️⃣  Запуск тестов..."
if command -v pytest &> /dev/null; then
    pytest tests/test_rating_system.py -v --tb=short 2>&1 | head -30
else
    echo "   ⚠️  pytest не установлен, пропускаем тесты"
    echo "   💡 Установите: pip3 install pytest"
fi
echo ""

# 7. Проверка линтера (если установлен)
echo "7️⃣  Проверка линтера..."
if command -v pylint &> /dev/null; then
    pylint rating_api_server.py --disable=all --enable=E,F 2>&1 | tail -5 || true
else
    echo "   ⚠️  pylint не установлен"
fi
echo ""

echo "✅ Проверка качества кода завершена!"
echo ""
echo "📋 Рекомендации:"
echo "   - Убедитесь что все print() заменены на logger"
echo "   - Проверьте что все тесты проходят"
echo "   - Убедитесь что API сервер запущен для полной проверки"

