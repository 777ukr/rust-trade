
# 🌐 Как просмотреть результаты в Freqtrade Web UI

## Прямые ссылки:

### 1. Страница Backtesting (основная):
http://127.0.0.1:8081/backtesting

### 2. API для получения результатов:

## Как использовать:

1. **Откройте веб-интерфейс:**
   ```
   http://127.0.0.1:8081/backtesting
   ```

2. **Войдите:**
   - Логин: `freqtrader`
   - Пароль: см. `config/freqtrade_config.json`

3. **Результаты автоматически появятся в разделе Backtesting**

4. **Или используйте API напрямую:**
   ```bash
   curl -u freqtrader:PASSWORD \
     http://127.0.0.1:8081/api/v1/backtest/history
   ```

## 📊 Статистика тестирования:
- AdvancedIndicatorStrategy: BTC/USDT (20251005-20251104)
- MStrikeStrategy: BTC/USDT (20251005-20251104)
- MShotStrategy: BTC/USDT (20251005-20251104)
- HookStrategy: BTC/USDT (20251005-20251104)
