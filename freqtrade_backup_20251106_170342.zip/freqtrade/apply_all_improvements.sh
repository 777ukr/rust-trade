#!/bin/bash
# Применить все улучшения к системе

echo "=========================================="
echo "🔧 ПРИМЕНЕНИЕ ВСЕХ УЛУЧШЕНИЙ"
echo "=========================================="
echo ""

cd /home/crypto/sites/cryptotrader.com/freqtrade

# 1. Проверка качества кода
echo "1️⃣  Проверка качества кода..."
python3 quality_check.py
QUALITY_EXIT=$?

# 2. Health Check
echo ""
echo "2️⃣  Health Check..."
python3 health_check.py
HEALTH_EXIT=$?

# 3. Комплексное тестирование
echo ""
echo "3️⃣  Комплексное тестирование..."
python3 comprehensive_test_suite.py
COMPREHENSIVE_EXIT=$?

# 4. Интеграционные тесты
echo ""
echo "4️⃣  Интеграционные тесты..."
python3 integration_test_suite.py
INTEGRATION_EXIT=$?

# 5. Проверка синтаксиса всех файлов
echo ""
echo "5️⃣  Проверка синтаксиса..."
python3 -m py_compile rating_api_server.py 2>&1 && echo "  ✅ rating_api_server.py" || echo "  ❌ rating_api_server.py"
python3 -m py_compile comprehensive_test_suite.py 2>&1 && echo "  ✅ comprehensive_test_suite.py" || echo "  ❌ comprehensive_test_suite.py"
python3 -m py_compile data_validator.py 2>&1 && echo "  ✅ data_validator.py" || echo "  ❌ data_validator.py"
python3 -m py_compile error_handler.py 2>&1 && echo "  ✅ error_handler.py" || echo "  ❌ error_handler.py"

# Итоги
echo ""
echo "=========================================="
echo "📊 ИТОГИ"
echo "=========================================="

FAILED=0
[ $QUALITY_EXIT -ne 0 ] && FAILED=$((FAILED + 1))
[ $COMPREHENSIVE_EXIT -ne 0 ] && FAILED=$((FAILED + 1))
[ $INTEGRATION_EXIT -ne 0 ] && FAILED=$((FAILED + 1))

if [ $FAILED -eq 0 ]; then
    echo "✅ ВСЕ УЛУЧШЕНИЯ ПРИМЕНЕНЫ УСПЕШНО!"
    echo ""
    echo "🎯 Система готова к использованию!"
    echo "   Откройте: http://localhost:8889"
    exit 0
else
    echo "⚠️  Некоторые проверки провалились"
    exit 1
fi



