#!/bin/bash
# Ручной тест бэктеста для диагностики

cd "$(dirname "$0")"
source .venv/bin/activate

STRATEGY="E0V1E_20231004_085308"
PAIR="SOL/USDT"
TIMEFRAME="5m"

echo "🧪 Тестирование бэктеста вручную..."
echo "   Стратегия: $STRATEGY"
echo "   Пара: $PAIR"
echo "   Timeframe: $TIMEFRAME"
echo ""

# Проверяем наличие стратегии
if [ ! -f "user_data/strategies/${STRATEGY}.py" ]; then
    echo "❌ Стратегия не найдена!"
    exit 1
fi

# Проверяем наличие данных
if [ ! -f "user_data/data/gateio/SOL_USDT-${TIMEFRAME}.json" ]; then
    echo "⚠️  Данные для $PAIR не найдены!"
    echo "   Скачиваю данные..."
    freqtrade download-data --exchange gateio --pairs "$PAIR" --timeframes "$TIMEFRAME" --days 30
fi

# Запускаем бэктест
echo "🚀 Запуск бэктеста..."
freqtrade backtesting \
    --config ../config/freqtrade_config.json \
    --strategy "$STRATEGY" \
    --pairs "$PAIR" \
    --timeframe "$TIMEFRAME" \
    --timerange 20241005-20241105 \
    --export trades \
    --breakdown month

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Бэктест завершен успешно!"
    echo "📊 Обновление рейтинга..."
    python3 strategy_rating_system_standalone.py
else
    echo ""
    echo "❌ Бэктест завершился с ошибкой"
    exit 1
fi

