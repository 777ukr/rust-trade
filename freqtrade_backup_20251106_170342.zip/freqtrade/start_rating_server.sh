#!/bin/bash
# Скрипт для запуска API сервера рейтинга стратегий

cd "$(dirname "$0")"

echo "🚀 Запуск API сервера рейтинга стратегий..."
echo ""

# Проверка зависимостей
echo "1️⃣  Проверка зависимостей..."
python3 -c "import fastapi" 2>/dev/null || {
    echo "   ❌ fastapi не установлен"
    echo "   💡 Установите: pip3 install -r requirements_rating.txt"
    exit 1
}

python3 -c "import uvicorn" 2>/dev/null || {
    echo "   ❌ uvicorn не установлен"
    echo "   💡 Установите: pip3 install -r requirements_rating.txt"
    exit 1
}

echo "   ✅ Зависимости установлены"
echo ""

# Проверка порта
PORT=8889
if lsof -Pi :$PORT -sTCP:LISTEN -t >/dev/null 2>&1 ; then
    echo "   ⚠️  Порт $PORT уже занят"
    echo "   💡 Остановите другой процесс или измените PORT в скрипте"
    exit 1
fi

echo "2️⃣  Запуск сервера на порту $PORT..."
echo "   URL: http://localhost:$PORT"
echo "   UI: http://localhost:$PORT/"
echo ""

# Запуск сервера
python3 -m uvicorn rating_api_server:app --host 0.0.0.0 --port $PORT --reload
