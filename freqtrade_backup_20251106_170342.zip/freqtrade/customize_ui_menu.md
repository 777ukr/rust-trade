# 🎨 Кастомизация меню FreqUI - Добавление Backtesting

## Вариант 1: Через fallback_file.html (простой способ)

Freqtrade использует `fallback_file.html` для кастомизации UI.

### Шаги:

1. **Найти оригинальный файл:**
   ```bash
   cd /home/crypto/sites/cryptotrader.com/freqtrade
   find .venv -name "fallback_file.html" -o -name "index.html" | grep ui
   ```

2. **Создать кастомный fallback:**
   ```bash
   cp .venv/lib/python3.11/site-packages/freqtrade/rpc/api_server/ui/fallback_file.html \
      user_data/ui_custom/fallback_file.html
   ```

3. **Добавить ссылку на Backtesting в меню**

4. **Указать путь в конфиге:**
   ```json
   {
     "api_server": {
       "ui_path": "user_data/ui_custom"
     }
   }
   ```

## Вариант 2: JavaScript injection (простой, работает сразу)

Создайте кастомный скрипт, который добавит ссылку в меню:

```javascript
// Добавить в fallback_file.html перед </body>
<script>
(function() {
    // Ждем загрузки меню
    setTimeout(function() {
        const nav = document.querySelector('nav') || document.querySelector('[role="navigation"]');
        if (nav) {
            // Находим существующий пункт меню для копирования стиля
            const existingItem = nav.querySelector('a[href*="dashboard"]');
            if (existingItem) {
                // Создаем новый пункт меню
                const backtestLink = existingItem.cloneNode(true);
                backtestLink.href = '/backtesting';
                backtestLink.textContent = 'Backtesting';
                backtestLink.innerHTML = '<span>Backtesting</span>';
                
                // Вставляем после Dashboard
                existingItem.parentNode.insertBefore(backtestLink, existingItem.nextSibling);
            }
        }
    }, 1000);
})();
</script>
```

## Вариант 3: Через кастомный роутер (продвинутый)

Если FreqUI использует Vue.js или React, нужно модифицировать роутер.

## Самый простой способ - через браузерное расширение

Создайте пользовательский скрипт (Tampermonkey/Greasemonkey):

```javascript
// ==UserScript==
// @name         FreqUI Add Backtesting Link
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Добавить ссылку Backtesting в меню FreqUI
// @match        http://127.0.0.1:8081/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    
    function addBacktestingLink() {
        const nav = document.querySelector('nav') || 
                   document.querySelector('[role="navigation"]') ||
                   document.querySelector('.sidebar') ||
                   document.querySelector('[class*="menu"]');
        
        if (!nav) return;
        
        // Проверяем, не добавлена ли уже ссылка
        if (nav.querySelector('a[href="/backtesting"]')) return;
        
        // Находим Dashboard для копирования стиля
        const dashboardLink = nav.querySelector('a[href*="dashboard"]') ||
                              nav.querySelector('a[href="/"]');
        
        if (dashboardLink) {
            const backtestLink = dashboardLink.cloneNode(true);
            backtestLink.href = '/backtesting';
            backtestLink.textContent = 'Backtesting';
            backtestLink.innerHTML = backtestLink.innerHTML.replace(/Dashboard|Home/, 'Backtesting');
            
            // Вставляем после Dashboard
            dashboardLink.parentNode.insertBefore(backtestLink, dashboardLink.nextSibling);
        }
    }
    
    // Пытаемся добавить ссылку несколько раз (на случай задержки загрузки)
    setTimeout(addBacktestingLink, 500);
    setTimeout(addBacktestingLink, 1500);
    setTimeout(addBacktestingLink, 3000);
    
    // Также при изменении DOM
    const observer = new MutationObserver(addBacktestingLink);
    observer.observe(document.body, { childList: true, subtree: true });
})();
```

