#!/usr/bin/env python3
"""
Полное тестирование BTC/USDT - проверка всего пайплайна
"""

import requests
import json
import time
import subprocess
from pathlib import Path

API_URL = "http://localhost:8889"
FREQTRADE_DIR = Path(__file__).parent
STRATEGY_NAME = "AdvancedIndicatorStrategy"
PAIR = "BTC/USDT"
TIMEFRAME = "5m"

def test_data_exists():
    """Проверка наличия данных"""
    print("1️⃣  Проверка данных OHLCV...")
    data_file = FREQTRADE_DIR / "user_data" / "data" / "binance" / f"{PAIR.replace('/', '_')}-{TIMEFRAME}.json"
    if data_file.exists():
        with open(data_file, 'r') as f:
            data = json.load(f)
            print(f"   ✅ Данные найдены: {len(data)} свечей")
            return True
    else:
        print(f"   ❌ Данные не найдены: {data_file}")
        return False

def test_backtest_exists():
    """Проверка наличия бэктеста"""
    print("2️⃣  Проверка бэктестов...")
    results_dir = FREQTRADE_DIR / "user_data" / "backtest_results"
    zip_files = list(results_dir.glob(f"*{STRATEGY_NAME}*.zip"))
    if zip_files:
        latest = sorted(zip_files, key=lambda x: x.stat().st_mtime, reverse=True)[0]
        print(f"   ✅ Найден бэктест: {latest.name}")
        return True
    else:
        print(f"   ❌ Бэктесты не найдены")
        return False

def run_backtest():
    """Запуск бэктеста"""
    print("3️⃣  Запуск бэктеста для BTC/USDT...")
    response = requests.post(
        f"{API_URL}/api/backtest/run",
        json={
            "strategy_name": STRATEGY_NAME,
            "pairs": [PAIR],
            "timeframe": TIMEFRAME
        },
        timeout=10
    )
    
    if response.status_code == 200:
        data = response.json()
        print(f"   ✅ Бэктест запущен: {data.get('message', '')}")
        print(f"   Timerange: {data.get('timerange', '')}")
        return True
    else:
        print(f"   ❌ Ошибка запуска: {response.status_code}")
        print(f"   {response.text}")
        return False

def wait_for_backtest(max_wait=300):
    """Ожидание завершения бэктеста"""
    print("4️⃣  Ожидание завершения бэктеста...")
    start_time = time.time()
    
    while time.time() - start_time < max_wait:
        # Проверяем процессы
        result = subprocess.run(
            ["ps", "aux"],
            capture_output=True,
            text=True
        )
        
        if "freqtrade" not in result.stdout or "backtest" not in result.stdout.lower():
            # Проверяем наличие новых файлов
            results_dir = FREQTRADE_DIR / "user_data" / "backtest_results"
            zip_files = list(results_dir.glob(f"*{STRATEGY_NAME}*.zip"))
            if zip_files:
                latest = sorted(zip_files, key=lambda x: x.stat().st_mtime, reverse=True)[0]
                age = time.time() - latest.stat().st_mtime
                if age < 60:  # Свежий файл (меньше минуты)
                    print(f"   ✅ Бэктест завершен: {latest.name}")
                    return True
        
        print(".", end="", flush=True)
        time.sleep(5)
    
    print("\n   ⚠️  Таймаут ожидания")
    return False

def test_chart_api():
    """Тестирование API графика"""
    print("5️⃣  Тестирование API графика...")
    
    response = requests.get(
        f"{API_URL}/api/strategies/{STRATEGY_NAME}/chart-data",
        params={"pair": PAIR, "timeframe": TIMEFRAME},
        timeout=10
    )
    
    if response.status_code == 200:
        data = response.json()
        has_data = data.get("has_data", False)
        ohlcv_count = len(data.get("ohlcv", []))
        entry_points = len(data.get("entry_points", []))
        
        print(f"   has_data: {has_data}")
        print(f"   OHLCV свечей: {ohlcv_count}")
        print(f"   Точки входа: {entry_points}")
        
        if has_data and (ohlcv_count > 0 or entry_points > 0):
            print(f"   ✅ API графика работает")
            return True
        else:
            print(f"   ❌ Нет данных для графика")
            print(f"   Сообщение: {data.get('message', '')}")
            return False
    else:
        print(f"   ❌ Ошибка API: {response.status_code}")
        return False

def test_strategy_details():
    """Тестирование деталей стратегии"""
    print("6️⃣  Тестирование деталей стратегии...")
    
    response = requests.get(
        f"{API_URL}/api/strategies/{STRATEGY_NAME}/details",
        timeout=10
    )
    
    if response.status_code == 200:
        print(f"   ✅ Детали стратегии доступны")
        return True
    else:
        print(f"   ⚠️  Детали стратегии: {response.status_code} (не критично)")
        return True

def main():
    """Главная функция"""
    print("=" * 70)
    print("🧪 ПОЛНОЕ ТЕСТИРОВАНИЕ BTC/USDT")
    print("=" * 70)
    print()
    
    results = []
    
    # 1. Проверка данных
    has_data = test_data_exists()
    results.append(("Data", has_data))
    print()
    
    # 2. Проверка бэктеста
    has_backtest = test_backtest_exists()
    results.append(("Backtest", has_backtest))
    print()
    
    # 3. Если нет бэктеста, запускаем
    if not has_backtest:
        if run_backtest():
            print()
            if wait_for_backtest():
                has_backtest = True
                results[1] = ("Backtest", True)
            else:
                print("   ⚠️  Бэктест еще выполняется...")
        print()
    
    # 4. Тестирование API графика
    chart_works = test_chart_api()
    results.append(("Chart API", chart_works))
    print()
    
    # 5. Тестирование деталей
    details_works = test_strategy_details()
    results.append(("Details API", details_works))
    print()
    
    # Итоги
    print("=" * 70)
    print("📊 РЕЗУЛЬТАТЫ")
    print("=" * 70)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✅" if result else "❌"
        print(f"{status} {name}")
    
    print()
    print(f"Успешно: {passed}/{total}")
    
    if passed == total:
        print("✅ ВСЕ ТЕСТЫ ПРОЙДЕНЫ!")
        print()
        print("🌐 Откройте в браузере:")
        print(f"   http://localhost:8889")
        print(f"   Кликните на стратегию {STRATEGY_NAME}")
        return True
    else:
        print("❌ ЕСТЬ ПРОБЛЕМЫ")
        return False

if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)


