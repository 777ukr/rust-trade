# ✅ Активные стратегии

## 📋 Список активных стратегий для тестирования

Только эти стратегии будут:
- ✅ Показываться в рейтинге
- ✅ Запускаться на бэктесты
- ✅ Отображаться в веб-интерфейсе

### Текущие активные стратегии:

1. **MShotStrategy** - Стратегия прострелов (MoonShot)
   - 9 бэктестов
   - Win Rate: 70%
   - Ninja Score: 1278.11

2. **E0V1E_20231004_085308** - RSI + CTI + SMA стратегия
   - Новая стратегия
   - Требует тестирования

## 🔧 Как добавить/убрать стратегию

### Изменить список активных стратегий:

Отредактируйте файлы:
- `strategy_rating_system_standalone.py` - переменная `ACTIVE_STRATEGIES`
- `rating_web_interface_standalone.py` - переменная `ACTIVE_STRATEGIES`
- `strategy_test_runner.py` - переменная `ACTIVE_STRATEGIES`

### Добавить стратегию:

1. Поместите файл стратегии в `user_data/strategies/`
2. Добавьте имя стратегии в `ACTIVE_STRATEGIES` во всех трех файлах
3. Запустите тест: `python3 strategy_test_runner.py --strategy StrategyName`
4. Обновите рейтинг: `python3 strategy_rating_system_standalone.py`

### Убрать стратегию:

1. Удалите имя стратегии из `ACTIVE_STRATEGIES`
2. Обновите рейтинг: `python3 strategy_rating_system_standalone.py`
3. Обновите веб-интерфейс: `python3 rating_web_interface_standalone.py`

## 📊 Критерии для активных стратегий

Стратегия считается активной если:
- ✅ Находится в списке `ACTIVE_STRATEGIES`
- ✅ Имеет хотя бы один бэктест с сделками (`total_trades > 0`)
- ✅ Не имеет lookahead bias
- ✅ Leverage = 1x

## 🚀 Быстрые команды

```bash
# Запустить тест одной стратегии
python3 strategy_test_runner.py --strategy MShotStrategy

# Запустить тесты всех активных стратегий
python3 strategy_test_runner.py --all

# Обновить рейтинг
python3 strategy_rating_system_standalone.py
python3 rating_web_interface_standalone.py
```



