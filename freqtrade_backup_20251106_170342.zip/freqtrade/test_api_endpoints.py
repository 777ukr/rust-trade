#!/usr/bin/env python3
"""
Тестирование всех API endpoints
"""

import requests
import json
from typing import Dict, Any

API_URL = "http://localhost:8889"

def test_endpoint(name: str, method: str, url: str, **kwargs) -> Dict[str, Any]:
    """Тестировать endpoint"""
    try:
        if method.upper() == "GET":
            response = requests.get(url, timeout=5, **kwargs)
        elif method.upper() == "POST":
            response = requests.post(url, timeout=5, **kwargs)
        else:
            return {"status": "error", "message": f"Unknown method: {method}"}
        
        try:
            data = response.json()
        except:
            data = {"raw": response.text[:200]}
        
        return {
            "name": name,
            "status_code": response.status_code,
            "success": response.status_code < 400,
            "data": data
        }
    except requests.exceptions.ConnectionError:
        return {
            "name": name,
            "status_code": 0,
            "success": False,
            "error": "Server not running"
        }
    except Exception as e:
        return {
            "name": name,
            "status_code": 0,
            "success": False,
            "error": str(e)
        }

def run_all_tests():
    """Запустить все тесты"""
    print("=" * 70)
    print("🧪 Тестирование API Endpoints")
    print("=" * 70)
    print()
    
    tests = [
        ("GET /", "GET", f"{API_URL}/"),
        ("GET /api/stats", "GET", f"{API_URL}/api/stats"),
        ("GET /api/strategies", "GET", f"{API_URL}/api/strategies"),
        ("GET /api/rankings", "GET", f"{API_URL}/api/rankings?min_trades=0&min_profit=-100&limit=10"),
        ("GET /api/rankings (with filters)", "GET", f"{API_URL}/api/rankings?min_trades=10&exclude_stalled=true&exclude_bias=true"),
    ]
    
    results = []
    for name, method, url in tests:
        result = test_endpoint(name, method, url)
        results.append(result)
        
        status = "✅" if result["success"] else "❌"
        print(f"{status} {name}")
        print(f"   Status: {result['status_code']}")
        if not result["success"]:
            if "error" in result:
                print(f"   Error: {result['error']}")
            elif "data" in result and "error" in result["data"]:
                print(f"   Error: {result['data']['error']}")
        print()
    
    # Summary
    print("=" * 70)
    passed = sum(1 for r in results if r["success"])
    total = len(results)
    print(f"📊 Результаты: {passed}/{total} тестов прошли")
    
    if passed == total:
        print("✅ Все тесты прошли успешно!")
    else:
        print("❌ Некоторые тесты не прошли")
        print("\nДетали ошибок:")
        for r in results:
            if not r["success"]:
                print(f"  - {r['name']}: {r.get('error', r.get('status_code', 'Unknown'))}")
    
    return passed == total

if __name__ == "__main__":
    success = run_all_tests()
    exit(0 if success else 1)

