# 🌐 Как открыть HTML файлы в браузере

## 📄 Локальные HTML файлы

У вас есть HTML файлы с рейтингом стратегий. Их можно открыть **без скачивания** прямо в браузере.

## 🚀 Способ 1: Прямой путь (самый простой)

### Скопируйте этот путь в адресную строку браузера:

```
file:///home/crypto/sites/cryptotrader.com/freqtrade/user_data/web/strategy_rankings.html
```

**Как это сделать:**
1. Откройте любой браузер (Chrome, Firefox, Edge)
2. Скопируйте путь выше
3. Вставьте в адресную строку (где обычно вводится URL)
4. Нажмите Enter

### Или используйте скрипт:

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
./open_ratings.sh
```

## 🌐 Способ 2: Через веб-сервер (рекомендуется)

### Запустите простой HTTP сервер:

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
python3 -m http.server 8888 --directory user_data/web
```

### Затем откройте в браузере:

```
http://localhost:8888/strategy_rankings.html
```

**Преимущества:**
- ✅ Работает как обычный сайт
- ✅ Можно использовать ссылки между страницами
- ✅ Нет проблем с CORS (если нужны AJAX запросы)

**Остановить сервер:** Нажмите `Ctrl+C` в терминале

## 📋 Доступные страницы

### Рейтинг стратегий:
```
file:///home/crypto/sites/cryptotrader.com/freqtrade/user_data/web/strategy_rankings.html
или
http://localhost:8888/strategy_rankings.html (если запущен сервер)
```

### Результаты бэктестов:
```
file:///home/crypto/sites/cryptotrader.com/freqtrade/user_data/web/backtest_results.html
или
http://localhost:8888/backtest_results.html (если запущен сервер)
```

## 🔍 Проверка файлов

Убедитесь, что файлы существуют:

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
ls -lh user_data/web/*.html
```

## ⚠️ Важно

- **НЕ нужно скачивать файлы** - они уже на вашем компьютере
- Просто откройте путь в браузере
- Файлы обновляются автоматически при запуске скриптов рейтинга

## 🎯 Быстрый доступ

Самый быстрый способ - использовать скрипт:

```bash
cd /home/crypto/sites/cryptotrader.com/freqtrade
./open_ratings.sh
```

Он автоматически откроет файл в браузере (если возможно) или покажет путь для копирования.



