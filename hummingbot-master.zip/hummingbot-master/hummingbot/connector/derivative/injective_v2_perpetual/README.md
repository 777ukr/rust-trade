## Injective v2 Perpetual

This is a perpetual connector created by **[Injective Labs](https://injectivelabs.org/)**.
The description and configuration steps for the perpetual connector are identical to the spot connector. Please check the README file in the Injective v2 spot connector folder.
